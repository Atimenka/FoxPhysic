package dev.foxphys;

import com.google.gson.JsonObject;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import dev.foxphys.Protocol.Snapshot;
import java.util.Locale;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2262;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

import static net.minecraft.class_2170.*;
import static dev.foxphys.Protocol.*;

public final class Commands {
    private Commands() {}
    static final String DEPRECATED_ALIAS="FoxPhys: команда /voxphys устарела и будет удалена. Используйте /foxphys или /fox.";
    @FunctionalInterface private interface Action {String run(class_2168 source);}
    private static int run(CommandContext<class_2168> ctx,Action action) {
        try {
            // The warning comes first, so it is shown even when the command itself is refused.
            if (ctx.getInput().startsWith("voxphys")) {
                ctx.getSource().method_9226(()->class_2561.method_43470(DEPRECATED_ALIAS),false);
            }
            String result=action.run(ctx.getSource());
            ctx.getSource().method_9226(()->class_2561.method_43470(result),false);return 1;
        } catch(RuntimeException | LinkageError e) {
            ctx.getSource().method_9213(class_2561.method_43470("FoxPhys: "+e.getMessage()));
            FoxPhysMod.LOGGER.warn("FoxPhys command failed: {}",e.toString());return 0;
        }
    }
    private static final String[] PRESET_NAMES={"rubber","jelly","cloth","rope"};
    /** /foxphys soft ...: мягкие тела (XPBD в Rust). Без коллизий с блоками, только плоскость пола. */
    private static LiteralArgumentBuilder<class_2168> soft(LabManager manager) {
        return method_9247("soft")
            .then(method_9247("spawn").then(method_9244("kind",StringArgumentType.word())
                .suggests((ctx,builder)->{for(String k:PRESET_NAMES)builder.suggest(k);return builder.buildFuture();})
                .executes(ctx->run(ctx,s->{
                    String kind=StringArgumentType.getString(ctx,"kind");
                    if (!java.util.Arrays.asList(PRESET_NAMES).contains(kind)) throw new IllegalArgumentException("Неизвестный вид: "+kind+" (rubber|jelly|cloth|rope)");
                    class_2338 feet=class_2338.method_49638(s.method_9222());
                    // 2 blocks east of the command position, 10 cm above the floor plane at feet level.
                    var out=SoftBodies.spawn(s.method_9225(),kind,feet.method_10263()+2.5,feet.method_10264()+0.1,feet.method_10260()+0.5,feet.method_10264());
                    return "Мягкое тело #"+out.get("id").getAsInt()+" ("+kind+", частиц "+out.get("particles").getAsInt()+"). Пол на уровне ног; блоки и физические тела сталкиваются с ним. Вода и мягкая физика крайне нестабильны.";
                }))))
            .then(method_9247("status").executes(ctx->run(ctx,s->SoftBodies.call("list",new com.google.gson.JsonObject()).toString()))
                .then(method_9244("id",IntegerArgumentType.integer(1)).executes(ctx->run(ctx,s->{
                    var o=SoftBodies.withId("status",IntegerArgumentType.getInteger(ctx,"id"));
                    return String.format(Locale.ROOT,"Тело #%d: %s, центр (%.2f, %.2f, %.2f), vmax %.2f м/с, объём %.3f..%.3f, жёсткость %.2f, демпфирование %.2f",
                        o.get("id").getAsInt(),o.get("preset").getAsString(),o.getAsJsonArray("center").get(0).getAsDouble(),o.getAsJsonArray("center").get(1).getAsDouble(),o.getAsJsonArray("center").get(2).getAsDouble(),
                        o.get("vmax").getAsDouble(),o.get("volume_ratio_min").getAsDouble(),o.get("volume_ratio_max").getAsDouble(),o.get("stiffness").getAsDouble(),o.get("damping").getAsDouble());
                }))))
            .then(method_9247("remove").then(method_9244("id",IntegerArgumentType.integer(1)).executes(ctx->run(ctx,s->{
                SoftBodies.remove(IntegerArgumentType.getInteger(ctx,"id"));
                return "Мягкое тело удалено.";
            }))))
            .then(method_9247("pin").then(method_9244("id",IntegerArgumentType.integer(1))
                .then(method_9244("side",StringArgumentType.word())
                    .suggests((ctx,builder)->{for(String k:new String[]{"top","bottom","start","end"})builder.suggest(k);return builder.buildFuture();})
                    .executes(ctx->run(ctx,s->{
                        com.google.gson.JsonObject a=new com.google.gson.JsonObject();
                        a.addProperty("id",IntegerArgumentType.getInteger(ctx,"id"));
                        a.addProperty("side",StringArgumentType.getString(ctx,"side"));
                        return "Закреплено частиц: "+SoftBodies.call("pin",a).get("pinned").getAsInt()+".";
                    })))))
            .then(method_9247("stiffness").then(method_9244("id",IntegerArgumentType.integer(1))
                .then(method_9244("value",FloatArgumentType.floatArg(0.05f,100f)).executes(ctx->run(ctx,s->{
                    com.google.gson.JsonObject a=new com.google.gson.JsonObject();
                    a.addProperty("id",IntegerArgumentType.getInteger(ctx,"id"));
                    a.addProperty("value",FloatArgumentType.getFloat(ctx,"value"));
                    return "Жёсткость тела установлена: "+SoftBodies.call("stiffness",a).get("stiffness").getAsDouble()+" (1.0 = пресет).";
                })))))
            .then(method_9247("damping").then(method_9244("id",IntegerArgumentType.integer(1))
                .then(method_9244("value",FloatArgumentType.floatArg(0f,50f)).executes(ctx->run(ctx,s->{
                    com.google.gson.JsonObject a=new com.google.gson.JsonObject();
                    a.addProperty("id",IntegerArgumentType.getInteger(ctx,"id"));
                    a.addProperty("value",FloatArgumentType.getFloat(ctx,"value"));
                    SoftBodies.call("damping",a);
                    return "Демпфирование установлено (1/с).";
                })))))
            .then(method_9247("attach").then(method_9244("id",IntegerArgumentType.integer(1))
                .then(method_9244("side",StringArgumentType.word())
                    .suggests((ctx,builder)->{for(String k:SoftAttachments.SIDES)builder.suggest(k);return builder.buildFuture();})
                    .executes(ctx->run(ctx,s->SoftAttachments.attach(manager.require(s.method_9225()),
                            IntegerArgumentType.getInteger(ctx,"id"),StringArgumentType.getString(ctx,"side"),null)))
                    .then(method_9244("body",LongArgumentType.longArg(1))
                        .executes(ctx->run(ctx,s->SoftAttachments.attach(manager.require(s.method_9225()),
                                IntegerArgumentType.getInteger(ctx,"id"),StringArgumentType.getString(ctx,"side"),
                                LongArgumentType.getLong(ctx,"body"))))))))
            .then(method_9247("detach").then(method_9244("id",IntegerArgumentType.integer(1)).executes(ctx->run(ctx,s->
                SoftAttachments.detach(IntegerArgumentType.getInteger(ctx,"id")) ? "Крепление снято." : "Крепления не было."))));
    }
    /** Основная команда /foxphys, короткий алиас /fox и временный алиас /voxphys (миграция с VoxPhys). */
    public static void register(CommandDispatcher<class_2168> dispatcher,LabManager manager) {
        dispatcher.register(root("foxphys",manager));
        dispatcher.register(root("fox",manager));
        dispatcher.register(root("voxphys",manager));
    }
    private static LiteralArgumentBuilder<class_2168> root(String name,LabManager manager) {
        return method_9247(name).requires(s->s.method_9259(2))
            .executes(ctx->run(ctx,s->"FoxPhys alpha: spawn wood/stone/boat/wing | water still/dam | spring | wind x y z | impulse id x y z | pause true/false | status | save | restore | assemble N | disassemble ID | clear | gun give | glue give | assembler give | assembler run x y z assemble/attach/disassemble | soft spawn/status/remove/pin/stiffness/damping/attach/detach | water sph still/dam/clear"))
            .then(method_9247("api").executes(ctx->run(ctx,s->dev.foxphys.api.FoxPhysApi.describe())))
            .then(method_9247("gun").then(method_9247("give").executes(ctx->run(ctx,s->{
                class_3222 player=s.method_44023();
                if (player == null) throw new IllegalStateException("Команда только для игрока");
                player.method_7270(new class_1799(FoxPhysBlocks.GUN));
                return "Гравипушка выдана. ПКМ — захват, ЛКМ при захвате — запуск.";
            }))))
            .then(method_9247("glue").then(method_9247("give").executes(ctx->run(ctx,s->{
                class_3222 player=s.method_44023();
                if (player == null) throw new IllegalStateException("Команда только для игрока");
                player.method_7270(new class_1799(FoxPhysBlocks.GLUE,16));
                return "Мёд-клей выдан (16). ПКМ по блоку склеивает связанную группу блоков в одно тело.";
            }))))
            .then(method_9247("assembler")
                .then(method_9247("give").executes(ctx->run(ctx,s->{
                    class_3222 player=s.method_44023();
                    if (player == null) throw new IllegalStateException("Команда только для игрока");
                    player.method_7270(new class_1799(FoxPhysBlocks.ASSEMBLER_ITEM));
                    return "Физический сборщик выдан. Ставь где нужно: физика создаётся рядом сама.";
                })))
                .then(method_9247("run").then(method_9244("pos",class_2262.method_9698())
                    .then(method_9244("mode",StringArgumentType.word())
                        .suggests((ctx,builder)->{for(Assembler.Mode m:Assembler.Mode.values())builder.suggest(m.id);return builder.buildFuture();})
                        .executes(ctx->run(ctx,s->{
                            class_2338 pos=class_2262.method_48299(ctx,"pos");
                            return Assembler.run(s.method_9225(),pos,Assembler.Mode.parse(StringArgumentType.getString(ctx,"mode")));
                        }))))))
            .then(method_9247("spawn").then(method_9244("type",StringArgumentType.word())
                .suggests((ctx,builder)->{for(String type:new String[]{"wood","stone","boat","wing"})builder.suggest(type);return builder.buildFuture();})
                .executes(ctx->run(ctx,s->{
                    Lab lab=manager.ensure(s.method_9225(),class_2338.method_49638(s.method_9222()));float[] p=lab.local(s.method_9222());p[1]+=4;
                    long id=lab.spawn(StringArgumentType.getString(ctx,"type"),p);
                    return "Тело #"+id+" создано (масса/силы рассчитываются в Rust).";
                }))))
            .then(method_9247("water")
                .then(method_9247("still").executes(ctx->run(ctx,s->{manager.require(s.method_9225()).water(false);return "Резервуар: спокойная вода, глубина 2 м.";})))
                .then(method_9247("dam").executes(ctx->run(ctx,s->{manager.require(s.method_9225()).water(true);return "Резервуар: разрыв плотины 3 м → 0.35 м; замкнутые границы.";})))
                .then(method_9247("sph")
                    .then(method_9247("still").executes(ctx->run(ctx,s->{dev.foxphys.fluid.FluidPool p=dev.foxphys.fluid.FluidWater.add(s.method_9225(),class_2338.method_49638(s.method_9222()).method_10084(),false);return "SPH-вода #"+p.id()+": "+p.particles()+" частиц, спокойная.";})))
                    .then(method_9247("dam").executes(ctx->run(ctx,s->{dev.foxphys.fluid.FluidPool p=dev.foxphys.fluid.FluidWater.add(s.method_9225(),class_2338.method_49638(s.method_9222()).method_10084(),true);return "SPH-вода #"+p.id()+": "+p.particles()+" частиц, разрыв плотины.";})))
                    .then(method_9247("clear").executes(ctx->run(ctx,s->{int n=dev.foxphys.fluid.FluidWater.count();dev.foxphys.fluid.FluidWater.clear();return "Удалено пулов SPH-воды: "+n+".";})))))
            .then(method_9247("spring").executes(ctx->run(ctx,s->{long id=manager.require(s.method_9225()).springDemo();return "Пружинный подвес тела #"+id+": k=6000 Н/м, c=1400 Н·с/м. Золотой маркер — неподвижный якорь.";})))
            .then(method_9247("wind").then(method_9244("x",FloatArgumentType.floatArg(-100,100))
                .then(method_9244("y",FloatArgumentType.floatArg(-100,100))
                .then(method_9244("z",FloatArgumentType.floatArg(-100,100)).executes(ctx->run(ctx,s->{
                    JsonObject c=op("set_wind");c.add("velocity",vector(FloatArgumentType.getFloat(ctx,"x"),FloatArgumentType.getFloat(ctx,"y"),FloatArgumentType.getFloat(ctx,"z")));
                    manager.require(s.method_9225()).commands(c);return "Скорость воздуха изменена (м/с).";
                }))))))
            .then(method_9247("impulse").then(method_9244("id",LongArgumentType.longArg(1))
                .then(method_9244("x",FloatArgumentType.floatArg(-2_000_000,2_000_000))
                .then(method_9244("y",FloatArgumentType.floatArg(-2_000_000,2_000_000))
                .then(method_9244("z",FloatArgumentType.floatArg(-2_000_000,2_000_000)).executes(ctx->run(ctx,s->{
                    JsonObject c=op("impulse");c.addProperty("id",LongArgumentType.getLong(ctx,"id"));
                    c.add("impulse",vector(FloatArgumentType.getFloat(ctx,"x"),FloatArgumentType.getFloat(ctx,"y"),FloatArgumentType.getFloat(ctx,"z")));
                    manager.require(s.method_9225()).commands(c);return "Импульс приложен (Н·с, НЕ м/с).";
                })))))))
            .then(method_9247("pause").then(method_9244("value",BoolArgumentType.bool()).executes(ctx->run(ctx,s->{
                JsonObject c=op("pause");c.addProperty("paused",BoolArgumentType.getBool(ctx,"value"));manager.require(s.method_9225()).commands(c);return "Пауза: "+BoolArgumentType.getBool(ctx,"value");
            }))))
            .then(method_9247("status").executes(ctx->run(ctx,s->{
                Lab lab=manager.require(s.method_9225());Snapshot state=lab.snapshot();
                String water=state.tank()==null?"нет":String.format(Locale.ROOT,"%.3f м³, ошибка объёма %.3g",state.tank().volume(),state.tank().relativeVolumeError());
                StringBuilder where=new StringBuilder();
                for(var b:state.bodies()){
                    if(where.length()>0)where.append("; ");
                    where.append(String.format(Locale.ROOT,"#%d (%.2f, %.2f, %.2f)",b.id(),b.position()[0]+lab.origin().method_10263(),b.position()[1]+lab.origin().method_10264(),b.position()[2]+lab.origin().method_10260()));
                }
                return String.format(Locale.ROOT,"Rust ABI %d | t=%.2f с | тел %d | коллайдеров %d | расчёт последнего тика %.3f мс | вода: %s | пауза %s | ошибка %s | скан: %s%s",
                    state.abi(),state.simSeconds(),state.bodies().size(),state.staticColliders(),state.lastStepUs()/1000.0,water,state.paused(),lab.failed(),lab.scanSkipped()?"часть тел вне бюджета":"полный",where.length()==0?"":" | позиции (мир): "+where);
            })))
            .then(method_9247("save").executes(ctx->run(ctx,s->{
                String file=manager.save(s.method_9225(),false);return "Сохранение поставлено в очередь: "+file;
            })))
            .then(method_9247("restore").executes(ctx->run(ctx,s->manager.restore(s.method_9225())+". Окружение (блоки, вода) не восстанавливается: оно считывается из мира.")))
            .then(method_9247("assemble").then(method_9244("size",IntegerArgumentType.integer(1,Assembler.MAX_ASSEMBLE_SIDE)).executes(ctx->run(ctx,s->{
                Lab lab=manager.ensure(s.method_9225(),class_2338.method_49638(s.method_9222()));int n=IntegerArgumentType.getInteger(ctx,"size");
                // Cube of n blocks, starting 2 blocks east of the command position.
                class_2338 min=class_2338.method_49638(s.method_9222()).method_10069(2,0,-n/2);
                String message = lab.assemble(min,n);
                manager.persistNow(s.method_9225());
                return message;
            }))))
            .then(method_9247("disassemble").then(method_9244("id",LongArgumentType.longArg(1)).executes(ctx->run(ctx,s->{
                String message = manager.require(s.method_9225()).disassemble(LongArgumentType.getLong(ctx,"id"));
                manager.persistNow(s.method_9225());
                return message;
            }))))
            .then(soft(manager))
            .then(method_9247("clear").executes(ctx->run(ctx,s->{manager.clear(s.method_9225());return "Физический мир и его визуальные объекты удалены. Блоки сборок возвращены на исходные места; остальные блоки мира не изменялись.";})))
        ;
    }
}
