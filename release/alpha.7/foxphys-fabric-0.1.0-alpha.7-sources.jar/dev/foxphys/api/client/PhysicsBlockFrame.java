package dev.foxphys.api.client;

import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import org.joml.Quaternionf;

/** Interpolated client pose for one visible block cell belonging to a rigid body. */
public record PhysicsBlockFrame(class_2338 cell, long bodyId, class_2680 originalState,
                                class_243 center, Quaternionf rotation) {
    public PhysicsBlockFrame {
        cell = cell.method_10062();
        rotation = new Quaternionf(rotation);
    }

    @Override public Quaternionf rotation() { return new Quaternionf(rotation); }
}
