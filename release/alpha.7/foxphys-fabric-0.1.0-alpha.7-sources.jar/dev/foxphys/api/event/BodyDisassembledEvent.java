package dev.foxphys.api.event;

import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

/** Fired after a body was taken apart and its blocks were put back into the world. */
public final class BodyDisassembledEvent extends FoxPhysEvent {
    private final class_3218 level;
    private final long bodyId;
    private final List<class_2338> returnedCells;
    private final int droppedBlocks;

    public BodyDisassembledEvent(class_3218 level, long bodyId, List<class_2338> returnedCells, int droppedBlocks) {
        this.level = level;
        this.bodyId = bodyId;
        this.returnedCells = List.copyOf(returnedCells);
        this.droppedBlocks = droppedBlocks;
    }

    public class_3218 level() { return level; }
    public long bodyId() { return bodyId; }
    /** World positions where blocks were placed back (unmodifiable). */
    public List<class_2338> returnedCells() { return returnedCells; }
    /** Blocks that could not be placed and dropped as items. */
    public int droppedBlocks() { return droppedBlocks; }
}
