package dev.foxphys.api.event;

import net.minecraft.class_2338;
import net.minecraft.class_3218;

/** Fired when a dimension gets its physics world for the first time (or after a failed one was replaced). */
public final class PhysicsWorldCreatedEvent extends FoxPhysEvent {
    private final class_3218 level;
    private final class_2338 origin;

    public PhysicsWorldCreatedEvent(class_3218 level, class_2338 origin) {
        this.level = level;
        this.origin = origin;
    }

    public class_3218 level() { return level; }
    /** Lab origin in world coordinates. */
    public class_2338 origin() { return origin; }
}
