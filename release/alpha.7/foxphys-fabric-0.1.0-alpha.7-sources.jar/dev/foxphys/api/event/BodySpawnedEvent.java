package dev.foxphys.api.event;

import net.minecraft.class_3218;

/** Fired after a rigid body was added to a physics world (by the API or by /foxphys spawn). */
public final class BodySpawnedEvent extends FoxPhysEvent {
    private final class_3218 level;
    private final long bodyId;
    private final String kind;

    public BodySpawnedEvent(class_3218 level, long bodyId, String kind) {
        this.level = level;
        this.bodyId = bodyId;
        this.kind = kind;
    }

    public class_3218 level() { return level; }
    public long bodyId() { return bodyId; }
    /** Body kind name: wood, stone, boat or wing. */
    public String kind() { return kind; }
}
