package dev.foxphys.api.event;

import net.minecraft.class_3218;

/** Fired after blocks were moved into a new body and the body exists in the native world. */
public final class BodyAssembledEvent extends FoxPhysEvent {
    private final class_3218 level;
    private final long bodyId;
    private final int blockCount;

    public BodyAssembledEvent(class_3218 level, long bodyId, int blockCount) {
        this.level = level;
        this.bodyId = bodyId;
        this.blockCount = blockCount;
    }

    public class_3218 level() { return level; }
    public long bodyId() { return bodyId; }
    /** Number of blocks that became part of the body. */
    public int blockCount() { return blockCount; }
}
