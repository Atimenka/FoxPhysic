package dev.foxphys.api.event;

import net.minecraft.class_3218;

/** Fired once per server tick for each dimension that has a physics world, after the world stepped. */
public final class PhysicsWorldTickEvent extends FoxPhysEvent {
    private final class_3218 level;

    public PhysicsWorldTickEvent(class_3218 level) {
        this.level = level;
    }

    public class_3218 level() { return level; }
}
