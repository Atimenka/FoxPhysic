package dev.foxphys.api;

import dev.foxphys.FoxPhysMod;
import dev.foxphys.Lab;
import dev.foxphys.Protocol;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.OptionalLong;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3218;

/**
 * A view of the rigid-body world of one dimension. Obtain it from {@link FoxPhysApi}. The view keeps
 * only the level; each call reads the current world, so it stays valid while the world is alive and
 * throws {@link IllegalStateException} after the world was closed or failed.
 *
 * <p>All coordinates are world coordinates unless a name says otherwise. Server thread only: every
 * method checks the thread and throws {@link IllegalStateException} when called from another one.
 */
public final class PhysicsWorld {
    private final class_3218 level;

    PhysicsWorld(class_3218 level) {
        this.level = level;
    }

    /** The dimension this world belongs to. */
    public class_3218 level() {
        return level;
    }

    /** The lab origin in world coordinates. */
    public class_2338 origin() {
        return lab().origin();
    }

    /**
     * Adds a rigid body with its centre of mass at {@code worldCentre}. The body starts at rest.
     *
     * @return the new body id, also sent in {@link dev.foxphys.api.event.BodySpawnedEvent}
     * @throws IllegalArgumentException if the position is not finite or the native side refuses
     */
    public long spawnBody(BodyKind kind, class_243 worldCentre) {
        if (kind == null) throw new IllegalArgumentException("kind is null");
        requireFinite(worldCentre, "worldCentre");
        Lab lab = lab();
        class_243 local = lab.toLocal(worldCentre);
        return lab.spawn(kind.id(), new float[] {(float) local.field_1352, (float) local.field_1351, (float) local.field_1350});
    }

    /**
     * Applies an impulse (N*s) at a world point. Synchronous: throws if the native side rejects it.
     *
     * @throws IllegalArgumentException if the body does not exist or the values are not finite
     */
    public void applyImpulse(long bodyId, class_243 impulse, class_243 worldPoint) {
        requireFinite(impulse, "impulse");
        requireFinite(worldPoint, "worldPoint");
        lab().impulse(bodyId, impulse, worldPoint);
    }

    /** Applies force in newtons for one game tick (50 ms), at the body's centre of mass. */
    public void applyForce(long bodyId, class_243 force) {
        applyForce(bodyId, force, null, 0.05);
    }

    /** Applies force in newtons for one game tick (50 ms), at a world-space point. */
    public void applyForce(long bodyId, class_243 force, class_243 worldPoint) {
        applyForce(bodyId, force, worldPoint, 0.05);
    }

    /** Applies force in newtons for a finite duration in seconds; a null point means the centre of mass. */
    public void applyForce(long bodyId, class_243 force, class_243 worldPoint, double durationSeconds) {
        requireFinite(force, "force");
        if (worldPoint != null) requireFinite(worldPoint, "worldPoint");
        requireDuration(durationSeconds);
        lab().applyForce(bodyId, force, worldPoint, durationSeconds);
    }

    /** Applies torque in newton-metres for one game tick (50 ms). */
    public void applyTorque(long bodyId, class_243 torque) {
        applyTorque(bodyId, torque, 0.05);
    }

    /** Applies torque in newton-metres for a finite duration in seconds. */
    public void applyTorque(long bodyId, class_243 torque, double durationSeconds) {
        requireFinite(torque, "torque");
        requireDuration(durationSeconds);
        lab().applyTorque(bodyId, torque, durationSeconds);
    }

    /** Sets angular velocity in radians per second, in world axes. */
    public void setAngularVelocity(long bodyId, class_243 angularVelocity) {
        requireFinite(angularVelocity, "angularVelocity");
        lab().setAngularVelocity(bodyId, angularVelocity);
    }

    /**
     * Moves a body to a pose and stops it. Synchronous.
     *
     * @param worldCentre centre of mass, world coordinates
     * @param quaternion  x, y, z, w; normalised here, so it does not need to be a unit quaternion
     */
    public void setPose(long bodyId, class_243 worldCentre, double[] quaternion) {
        requireFinite(worldCentre, "worldCentre");
        if (quaternion == null || quaternion.length != 4) throw new IllegalArgumentException("quaternion needs x, y, z, w");
        double n = 0;
        for (double q : quaternion) {
            if (!Double.isFinite(q)) throw new IllegalArgumentException("quaternion is not finite");
            n += q * q;
        }
        if (n < 1e-12) throw new IllegalArgumentException("quaternion has zero length");
        n = Math.sqrt(n);
        Lab lab = lab();
        class_243 local = lab.toLocal(worldCentre);
        lab.setPose(bodyId,
                new float[] {(float) local.field_1352, (float) local.field_1351, (float) local.field_1350},
                new float[] {(float) (quaternion[0] / n), (float) (quaternion[1] / n),
                        (float) (quaternion[2] / n), (float) (quaternion[3] / n)});
    }

    /** A body by id, or empty when it does not exist in the last snapshot. */
    public Optional<BodyInfo> body(long bodyId) {
        Protocol.BodyState state = lab().bodyById(bodyId);
        return state == null ? Optional.empty() : Optional.of(toInfo(state, lab()));
    }

    /** Bodies whose bounds intersect a world-coordinate box, from the last snapshot. */
    public List<BodyInfo> bodiesIn(class_238 region) {
        if (region == null) throw new IllegalArgumentException("region is null");
        List<BodyInfo> out = new ArrayList<>();
        for (BodyInfo b : bodies()) {
            if (b.bounds() != null && b.bounds().method_994(region)) out.add(b);
        }
        return out;
    }

    /** Every rigid body in the last snapshot. */
    public List<BodyInfo> bodies() {
        Lab lab = lab();
        Protocol.Snapshot snap = lab.snapshot();
        if (snap == null) return List.of();
        List<BodyInfo> out = new ArrayList<>(snap.bodies().size());
        for (Protocol.BodyState b : snap.bodies()) out.add(toInfo(b, lab));
        return out;
    }

    /**
     * The body whose box is nearest to {@code worldPoint}, within {@code radius} metres. Empty if none.
     */
    public Optional<BodyInfo> nearestBody(class_243 worldPoint, double radius) {
        requireFinite(worldPoint, "worldPoint");
        if (!(radius >= 0) || !Double.isFinite(radius)) throw new IllegalArgumentException("radius must be >= 0");
        Lab lab = lab();
        Protocol.BodyState b = lab.bodyNear(worldPoint, radius);
        return b == null ? Optional.empty() : Optional.of(toInfo(b, lab));
    }

    /**
     * Turns the blocks of a cube into one body, with the cube's minimum corner at {@code min}.
     *
     * @param size edge length in blocks, 1 or more
     * @return the body id, or empty when a {@link dev.foxphys.api.event.AssembleRequestedEvent} listener cancelled it
     * @throws IllegalArgumentException if no block can be taken or the limits of the world are reached
     */
    public OptionalLong assemble(class_2338 min, int size) {
        if (min == null) throw new IllegalArgumentException("min is null");
        if (size < 1 || size > 16) throw new IllegalArgumentException("size must be 1..16");
        List<class_2338> cells = new ArrayList<>(size * size * size);
        for (int x = 0; x < size; x++)
            for (int y = 0; y < size; y++)
                for (int z = 0; z < size; z++) cells.add(min.method_10069(x, y, z));
        return assembleCells(cells);
    }

    /**
     * Turns the given world cells into one body. Cells that cannot be converted (air, fluids, block
     * entities, unbreakable blocks) are skipped. A refusal changes nothing.
     *
     * @return the body id, or empty when a listener cancelled the request
     */
    public OptionalLong assembleCells(Collection<class_2338> worldCells) {
        if (worldCells == null) throw new IllegalArgumentException("worldCells is null");
        Lab.AssemblyResult result = lab().assembleBody(new ArrayList<>(worldCells));
        return result == null ? OptionalLong.empty() : OptionalLong.of(result.id());
    }

    /**
     * Takes a body apart and puts its blocks back, if it was made from blocks and is not rotated.
     * Fires {@link dev.foxphys.api.event.BodyDisassembledEvent}.
     *
     * @throws IllegalArgumentException if the body is unknown, is not an assembly, or is rotated
     */
    public void disassemble(long bodyId) {
        lab().disassemble(bodyId);
    }

    /** Original block states of an assembled body, in unspecified order; empty for non-assemblies. */
    public List<net.minecraft.class_2680> getBlockStates(long bodyId) {
        return lab().blockStates(bodyId);
    }

    /** Freezes or resumes the simulation. Bodies keep their poses while paused. */
    public void setPaused(boolean paused) {
        lab().setPaused(paused);
    }

    /** True while the simulation is frozen (by this API, by a command, or because no player is near). */
    public boolean isPaused() {
        Protocol.Snapshot snap = lab().snapshot();
        return snap != null && snap.paused();
    }

    /** Sets wind velocity in m/s, world axes. Applied to every body. */
    public void setWind(class_243 velocity) {
        requireFinite(velocity, "velocity");
        lab().setWind(velocity);
    }

    /** Counters of this world at the last completed step. */
    public WorldStats stats() {
        Lab lab = lab();
        Protocol.Snapshot snap = lab.snapshot();
        if (snap == null) return new WorldStats(0, 0, 0, lab.assemblyCount(), 0, 0, false);
        return new WorldStats(snap.simSeconds(), snap.fixedSteps(), snap.bodies().size(), lab.assemblyCount(),
                snap.staticColliders(), snap.lastStepUs(), snap.paused());
    }

    /** The lab as it is now. Fails when the world was closed or replaced, or on a foreign thread. */
    private Lab lab() {
        FoxPhysApi.requireServerThread(level);
        Lab lab = FoxPhysMod.manager().labFor(level);
        if (lab == null) throw new IllegalStateException("No physics world in " + level.method_27983().method_29177());
        if (lab.failed()) throw new IllegalStateException("Physics world failed; restart the server");
        return lab;
    }

    private static BodyInfo toInfo(Protocol.BodyState b, Lab lab) {
        class_243 centre = lab.toWorld(new class_243(b.position()[0], b.position()[1], b.position()[2]));
        class_243 velocity = new class_243(b.velocity()[0], b.velocity()[1], b.velocity()[2]);
        class_243 angular = new class_243(b.angularVelocity()[0], b.angularVelocity()[1], b.angularVelocity()[2]);
        class_238 bounds = null;
        if (b.aabbMin() != null && b.aabbMax() != null) {
            bounds = new class_238(lab.toWorld(new class_243(b.aabbMin()[0], b.aabbMin()[1], b.aabbMin()[2])),
                    lab.toWorld(new class_243(b.aabbMax()[0], b.aabbMax()[1], b.aabbMax()[2])));
        }
        double[] rotation = {b.rotation()[0], b.rotation()[1], b.rotation()[2], b.rotation()[3]};
        return new BodyInfo(b.id(), centre, rotation, b.mass(), velocity, angular, bounds, b.parts().size(),
                lab.isAssembly(b.id()));
    }

    private static void requireDuration(double seconds) {
        if (!Double.isFinite(seconds) || seconds < 0.001 || seconds > 10.0) {
            throw new IllegalArgumentException("durationSeconds must be finite and in [0.001, 10]");
        }
    }

    private static void requireFinite(class_243 v, String name) {
        if (v == null || !Double.isFinite(v.field_1352) || !Double.isFinite(v.field_1351) || !Double.isFinite(v.field_1350)) {
            throw new IllegalArgumentException(name + " must be a finite vector");
        }
    }
}
