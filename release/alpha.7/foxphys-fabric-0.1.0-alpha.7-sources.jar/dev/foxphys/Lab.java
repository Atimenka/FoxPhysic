package dev.foxphys;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import dev.foxphys.block.PhysicsBlockEntity;
import dev.foxphys.mixin.BlockDisplayAccessor;
import dev.foxphys.mixin.DisplayAccessor;
import dev.foxphys.nativecore.NativeBridge;
import dev.foxphys.nativecore.NativeLoader;
import java.util.*;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3486;
import net.minecraft.class_4590;
import net.minecraft.class_7923;
import net.minecraft.class_8113;
import dev.foxphys.Protocol.ActorContact;
import dev.foxphys.Protocol.BodyState;
import dev.foxphys.Protocol.Part;
import dev.foxphys.Protocol.Result;
import dev.foxphys.Protocol.Snapshot;
import dev.foxphys.Protocol.TankSpec;
import dev.foxphys.Protocol.TankState;
import dev.foxphys.api.event.AssembleRequestedEvent;
import dev.foxphys.api.event.BodyAssembledEvent;
import dev.foxphys.api.event.BodyDisassembledEvent;
import dev.foxphys.api.event.BodySpawnedEvent;
import dev.foxphys.api.event.FoxPhysEvents;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import static dev.foxphys.Protocol.*;

/** One physics world per dimension, created on first use (no fixed stand region).
 * All coordinates crossing JNI are relative to an integer Minecraft anchor (the first body's position).
 * Java only samples geometry and presents Rust results; it never integrates motion.
 */
public final class Lab implements AutoCloseable {
    public static final String TAG = "foxphys_lab";
    private final class_3218 world;
    private final class_2338 origin;
    private final FoxPhysConfig config;
    private final LabManager manager;
    private final long handle;
    private final Map<Long, List<class_8113.class_8115>> bodyVisuals = new HashMap<>();
    private final List<class_8113.class_8115> tankVisuals = new ArrayList<>();
    private final List<class_8113.class_8115> waterVisuals = new ArrayList<>();
    private final List<class_8113.class_8115> markers = new ArrayList<>();
    private Snapshot snapshot;
    private long nextId = 1;
    private int ticks;
    /** Numeric terrain geometry -> native key. JSON is built only for boxes that changed. */
    private record TerrainBox(double centerX, double centerY, double centerZ,
                              double sizeX, double sizeY, double sizeZ) {}
    private final Map<TerrainBox, Long> terrainIds = new HashMap<>();
    /** Reused per scan to avoid allocating boxed Longs or a large primitive table every tick. */
    private final LongOpenHashSet scannedCells = new LongOpenHashSet();
    private long nextTerrainId = 1;
    /** Blocks moved into physics bodies by /foxphys assemble, keyed by body id. */
    private final Map<Long, Assembly> assemblies = new LinkedHashMap<>();
    /** cells: lab-local block position -> original state. */
    /** simAt: simulation time of the first snapshot that contained the body. */
    /** blocks: true when the cells are drawn as PhysicsBlocks; false when they stay on block displays (attached to a body that was not assembled). */
    private record Assembly(Map<class_2338, class_2680> cells, double simAt, boolean blocks) {}
    /** Identity of this lab. A physics block stores it; blocks of another (dead) lab are leftovers. */
    private final UUID token = UUID.randomUUID();
    /** body id -> cell (lab-local) -> world position of its PhysicsBlock. Only cells that got a block. */
    private final Map<Long, Map<class_2338, class_2338>> placedCells = new HashMap<>();
    /** body id -> cell -> block display, for cells that could not get a PhysicsBlock (occupied or unloaded). */
    private final Map<Long, Map<class_2338, class_8113.class_8115>> cellVisuals = new HashMap<>();
    private String waterCache;
    private String tankKey;
    private boolean failed;
    private boolean idle;
    private boolean scanSkipped;
    /** Set by assemble: the cells became bodies, so the terrain must drop them before the next step. */
    private boolean scanPending;
    /** Set by a synchronous call: published snapshots must reach a later physics step before they are used. */
    private boolean awaitingStep;
    private long syncSteps;
    private int staleSnapshots;
    /** True while the lab is paused because no player is near (not a manual /foxphys pause). */
    private boolean frozenByIdle;
    /** Fixed-step id of the last actor contact result that was applied to entities. */
    private long lastContactStep = -1;
    /** True when the last push carried actor boxes (so an empty push is needed when nobody is near). */
    private boolean actorsPushed;
    private boolean closed;

    public Lab(class_3218 world, class_2338 origin, FoxPhysConfig config, LabManager manager) {
        this.world = world; this.origin = origin.method_10062(); this.config = config; this.manager = manager;
        NativeLoader.ensureLoaded();
        handle = NativeBridge.workerCreate(config.nativeJson());
        snapshot = GSON.fromJson(NativeBridge.workerCall(handle, "{}"), Snapshot.class);
    }
    public class_2338 origin() { return origin; }
    public Snapshot snapshot() { return snapshot; }
    public boolean scanSkipped() { return scanSkipped; }
    public boolean failed() { return failed; }
    public float[] local(class_243 point) {
        return new float[]{(float)(point.field_1352-origin.method_10263()), (float)(point.field_1351-origin.method_10264()), (float)(point.field_1350-origin.method_10260())};
    }
    /** A player within 64 blocks of the anchor or of any body keeps this world running (Sable-aware when installed). */
    private boolean playersNear() {
        List<class_243> points = new ArrayList<>();
        points.add(new class_243(origin.method_10263(), origin.method_10264(), origin.method_10260()));
        if (snapshot != null) for (BodyState b : snapshot.bodies()) points.add(worldPoint(b.position()));
        return world.method_18456().stream().anyMatch(p -> points.stream().anyMatch(c -> dev.foxphys.compat.SableBridge.distanceSquared(world, p.method_19538(), c) < 64 * 64));
    }
    public void tick() {
        if (closed || failed) return;
        // Distant/unobserved labs keep running at the worker's idle rate. Nothing catches up.
        boolean near = playersNear();
        if (near == idle) {
            idle = !near;
            NativeBridge.workerSetIdle(handle, idle);
        }
        drainWorkerErrors();
        if (failed) return;
        try {
            // Bodies freeze while nobody is near: terrain is only maintained where players are.
            // Without this a body could fall through blocks placed while the lab was unobserved.
            if (!near && !frozenByIdle && !snapshot.paused()) setFrozen(true);
            else if (near && frozenByIdle) setFrozen(false);
            if (near) {
                ticks++;
                JsonObject request = new JsonObject();
                if (ticks == 1 || scanPending || ticks % config.environmentScanInterval == 0) {
                    scanEnvironment(request);
                    // A body from assemble reaches the snapshot one step later. Until every assembled body
                    // is in the snapshot its region has no terrain, so the scan stays pending; otherwise the
                    // body falls through the ground until the next interval scan.
                    scanPending = snapshot == null || snapshot.bodies().size() < assemblies.size();
                }
                // Actors and grabs are replaced every tick: they describe the current players.
                request.add("actors", actorBoxes());
                request.add("grabs", manager.interactions().grabsFor(this));
                NativeBridge.workerPush(handle, request.toString());
                actorsPushed = true;
            } else if (actorsPushed) {
                // Nobody is near: release actors and grabs so no stale box keeps holding bodies.
                JsonObject request = new JsonObject();
                request.add("actors", new JsonArray());
                request.add("grabs", new JsonArray());
                NativeBridge.workerPush(handle, request.toString());
                actorsPushed = false;
            }
            // Read even when nobody is near: status stays current and expired bodies are noticed.
            String json = NativeBridge.workerLatest(handle);
            if (json != null) {
                Snapshot latest = GSON.fromJson(json, Snapshot.class);
                if (latest == null || latest.abi() != NativeBridge.ABI) throw new IllegalStateException("Invalid native snapshot");
                // A published snapshot that predates the last synchronous command (import_state is applied
                // without a physics step) would put the old bodies back: skip it until a newer step is published.
                if (awaitingStep && latest.fixedSteps() <= syncSteps && ++staleSnapshots < 20) latest = null; // paused world: stop waiting
                else { awaitingStep = false; staleSnapshots = 0; }
                if (latest != null) {
                    snapshot = latest;
                    reconcileBodies(latest);
                    applyContacts(latest);
                    if (near) updateBodyBlocks();
                    if (near && ticks % config.visualUpdateInterval == 0) updateVisuals();
                }
            }
        } catch (RuntimeException | LinkageError e) {
            failed = true;
            FoxPhysMod.LOGGER.error("FoxPhys physics world disabled after an error; restart the server to re-create it", e);
        }
    }
    /** Metres per tick that a standing entity is carried by the body it stands on. */
    private static final double CARRY_SECONDS = 0.05;
    /** Living entities pushed by bodies: boxes in lab coordinates, at most MAX_ACTORS. */
    private static final int MAX_ACTORS = 64;
    private JsonArray actorBoxes() {
        JsonArray list = new JsonArray();
        class_243 center = new class_243(origin.method_10263() + 8, origin.method_10264() + 10, origin.method_10260() + 8);
        class_238 area = new class_238(center.field_1352 - 48, center.field_1351 - 48, center.field_1350 - 48, center.field_1352 + 48, center.field_1351 + 48, center.field_1350 + 48);
        for (class_1309 e : world.method_8390(class_1309.class, area, Lab::isActor)) {
            if (list.size() >= MAX_ACTORS) break;
            class_238 b = e.method_5829();
            JsonObject a = new JsonObject();
            // Entity ids are non-negative; +1 keeps the key non-zero as the native side requires.
            a.addProperty("key", (long) e.method_5628() + 1L);
            a.add("center", vector(b.method_1005().field_1352 - origin.method_10263(), b.method_1005().field_1351 - origin.method_10264(), b.method_1005().field_1350 - origin.method_10260()));
            a.add("half", vector(clampHalf((b.field_1320 - b.field_1323) / 2), clampHalf((b.field_1325 - b.field_1322) / 2), clampHalf((b.field_1324 - b.field_1321) / 2)));
            a.addProperty("mass", 80.0);
            list.add(a);
        }
        return list;
    }
    private static boolean isActor(class_1309 e) {
        return e.method_5805() && !e.method_7325();
    }
    private static double clampHalf(double v) {
        return Math.max(0.05, Math.min(4.0, v));
    }
    /**
     * Moves entities out of bodies. Each contact result is applied once (by fixed-step id), so a
     * paused world does not push anybody repeatedly.
     */
    private void applyContacts(Snapshot s) {
        if (s.contacts() == null || s.contactStep() <= lastContactStep) return;
        lastContactStep = s.contactStep();

        for (ActorContact c : s.contacts()) {
            if (!(world.method_8469((int) (c.actor() - 1L)) instanceof class_1309 living) || !living.method_5805()) continue;
            float[] d = c.correction(), carry = c.carry();
            // A body above an entity pushes it down, but the entity is held by the ground: the
            // downward part is not applied (the body receives the matching impulse in Rust instead).
            // Carry from a moving body still applies, so an entity riding a body moves with it.
            double dx = d[0] + carry[0] * CARRY_SECONDS;
            double dy = Math.max(d[1], 0.0) + carry[1] * CARRY_SECONDS;
            double dz = d[2] + carry[2] * CARRY_SECONDS;
            if (dx * dx + dy * dy + dz * dz < 1e-8 && !c.standing()) continue;
            double x = living.method_23317() + dx, y = living.method_23318() + dy, z = living.method_23321() + dz;
            if (living instanceof class_3222 player) {
                player.field_13987.method_14363(x, y, z, player.method_36454(), player.method_36455());
            } else {
                living.method_5814(x, y, z);
            }
            if (c.standing()) {
                living.field_6017 = 0;
                living.method_24830(true);
                class_243 v = living.method_18798();
                // Sneaking holds the player on the body: no horizontal momentum of its own. The carry
                // above still moves the player with the body.
                double vx = living.method_5715() ? 0 : v.field_1352;
                double vz = living.method_5715() ? 0 : v.field_1350;
                living.method_18800(vx, Math.max(0, v.field_1351), vz);
                living.field_6037 = true;
            }
        }
    }
    /** Applies the newest contact result if it has not been applied yet. Called from PlayerEntity.tick (HEAD). */
    public void applyLatestContacts() {
        if (closed || failed || snapshot == null) return;
        applyContacts(snapshot);
    }
    /** True when the physics block at p belongs to this lab's body cell (used to clean leftovers after a chunk load). */
    public boolean holdsPhysicsBlock(class_2338 p, long bodyId, UUID owner) {
        if (!token.equals(owner)) return false;
        Map<class_2338, class_2338> cells = placedCells.get(bodyId);
        return cells != null && cells.containsValue(p);
    }
    /**
     * Queues an outward impulse for each body whose bounds intersect a vanilla explosion radius.
     * This deliberately uses one batched worker message so a blast cannot block the server thread
     * once complex bodies are allowed to contain hundreds of parts.
     */
    public void applyExplosion(class_243 worldCenter, float power) {
        if (closed || failed || snapshot == null || worldCenter == null || !Float.isFinite(power) || power <= 0.0f) return;
        double radius = Math.min(128.0, power * 2.0);
        if (!(radius > 0.0)) return;
        class_243 blast = toLocal(worldCenter);
        JsonArray impulses = new JsonArray();
        for (BodyState body : snapshot.bodies()) {
            float[] center = body.position(), min = body.aabbMin(), max = body.aabbMax();
            if (center == null || center.length < 3 || min == null || min.length < 3 || max == null || max.length < 3
                    || !Float.isFinite(body.mass()) || body.mass() <= 0.0f) continue;
            double px = Math.max(min[0], Math.min(max[0], blast.field_1352));
            double py = Math.max(min[1], Math.min(max[1], blast.field_1351));
            double pz = Math.max(min[2], Math.min(max[2], blast.field_1350));
            double dx = px - blast.field_1352, dy = py - blast.field_1351, dz = pz - blast.field_1350;
            double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (!(distance < radius)) continue;
            double falloff = 1.0 - distance / radius;
            double directionLength = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (directionLength < 1e-6) {
                dx = center[0] - blast.field_1352; dy = center[1] - blast.field_1351; dz = center[2] - blast.field_1350;
                directionLength = Math.sqrt(dx * dx + dy * dy + dz * dz);
            }
            if (directionLength < 1e-6) { dx = 0.0; dy = 1.0; dz = 0.0; directionLength = 1.0; }
            double deltaV = Math.min(8.0, power * 0.75 * falloff);
            double impulseSize = Math.min(1_000_000.0, body.mass() * deltaV);
            if (!(impulseSize > 0.0)) continue;
            JsonObject command = op("impulse");
            command.addProperty("id", body.id());
            command.add("impulse", vector(dx / directionLength * impulseSize,
                    dy / directionLength * impulseSize, dz / directionLength * impulseSize));
            // Apply at the nearest point on the body's bounds to add a plausible blast torque.
            command.add("point", vector(px, py, pz));
            impulses.add(command);
        }
        if (impulses.isEmpty()) return;
        JsonObject request = new JsonObject();
        request.add("commands", impulses);
        try {
            NativeBridge.workerPush(handle, request.toString());
        } catch (RuntimeException | LinkageError e) {
            FoxPhysMod.LOGGER.warn("FoxPhys could not queue explosion impulses", e);
        }
    }

    /** Queues a bounded batch of lab-local commands returned by fluid, soft-body, and API force coupling. */
    public void queueCouplingImpulses(JsonArray commands) {
        if (closed || failed || commands == null || commands.isEmpty()) return;
        JsonObject request = new JsonObject();
        request.add("commands", commands);
        try {
            NativeBridge.workerPush(handle, request.toString());
        } catch (RuntimeException | LinkageError e) {
            FoxPhysMod.LOGGER.warn("FoxPhys could not queue coupled physics commands", e);
        }
    }

    /** Applies an impulse (N*s) to a body at a world point. Synchronous: throws if rejected. */
    public void impulse(long id, class_243 impulseWorld, class_243 pointWorld) {
        JsonObject command = op("impulse");
        command.addProperty("id", id);
        command.add("impulse", vector(impulseWorld.field_1352, impulseWorld.field_1351, impulseWorld.field_1350));
        class_243 local = toLocal(pointWorld);
        command.add("point", vector(local.field_1352, local.field_1351, local.field_1350));
        commands(command);
    }
    public void applyForce(long id, class_243 forceWorld, class_243 pointWorld, double duration) {
        JsonObject command = op("apply_force");
        command.addProperty("id", id);
        command.add("force", vector(forceWorld.field_1352, forceWorld.field_1351, forceWorld.field_1350));
        if (pointWorld != null) {
            class_243 local = toLocal(pointWorld);
            command.add("point", vector(local.field_1352, local.field_1351, local.field_1350));
        }
        command.addProperty("duration", duration);
        commands(command);
    }
    public void applyTorque(long id, class_243 torque, double duration) {
        JsonObject command = op("apply_torque");
        command.addProperty("id", id);
        command.add("torque", vector(torque.field_1352, torque.field_1351, torque.field_1350));
        command.addProperty("duration", duration);
        commands(command);
    }
    public void setAngularVelocity(long id, class_243 velocity) {
        JsonObject command = op("set_angular_velocity");
        command.addProperty("id", id);
        command.add("velocity", vector(velocity.field_1352, velocity.field_1351, velocity.field_1350));
        commands(command);
    }
    /** Freezes (true) or resumes (false) the simulation. Bodies keep their poses while paused. */
    public void setPaused(boolean paused) {
        JsonObject command = op("pause");
        command.addProperty("paused", paused);
        commands(command);
    }
    /** Sets the wind velocity (m/s, world axes) applied to every body. */
    public void setWind(class_243 velocity) {
        JsonObject command = op("set_wind");
        command.add("velocity", vector(velocity.field_1352, velocity.field_1351, velocity.field_1350));
        commands(command);
    }
    /** Sets a body's pose (centre of mass and quaternion x, y, z, w, lab-local) and stops it. Synchronous. */
    public void setPose(long id, float[] position, float[] rotation) {
        JsonObject command = op("set_pose");
        command.addProperty("id", id);
        command.add("position", vector(position[0], position[1], position[2]));
        command.add("rotation", vector(rotation[0], rotation[1], rotation[2], rotation[3]));
        commands(command);
    }
    public class_243 toLocal(class_243 world) { return world.method_1023(origin.method_10263(), origin.method_10264(), origin.method_10260()); }
    public class_243 toWorld(class_243 local) { return local.method_1031(origin.method_10263(), origin.method_10264(), origin.method_10260()); }
    /** Nearest body whose box lies within `radius` of the world point, or null. */
    public BodyState bodyNear(class_243 worldPoint, double radius) {
        if (snapshot == null) return null;
        class_243 p = toLocal(worldPoint);
        BodyState best = null; double bestD = radius;
        for (BodyState b : snapshot.bodies()) {
            if (b.aabbMin() == null || b.aabbMax() == null) continue;
            double dx = Math.max(0, Math.max(b.aabbMin()[0] - p.field_1352, p.field_1352 - b.aabbMax()[0]));
            double dy = Math.max(0, Math.max(b.aabbMin()[1] - p.field_1351, p.field_1351 - b.aabbMax()[1]));
            double dz = Math.max(0, Math.max(b.aabbMin()[2] - p.field_1350, p.field_1350 - b.aabbMax()[2]));
            double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (d <= bestD) { bestD = d; best = b; }
        }
        return best;
    }
    private void setFrozen(boolean value) {
        JsonObject command = op("pause");
        command.addProperty("paused", value);
        commands(command);
        frozenByIdle = value;
    }
    /**
     * A body that was present and then vanished from a snapshot newer than its creation was removed
     * natively (Rust drops bodies beyond 128 m). Its blocks go back to the recorded cells instead of
     * being lost. Snapshots older than the creation are ignored, so a stale read cannot restore blocks
     * of a live body.
     */
    private void reconcileBodies(Snapshot latest) {
        Set<Long> present = new HashSet<>();
        for (BodyState b : latest.bodies()) present.add(b.id());
        Iterator<Map.Entry<Long, Assembly>> it = assemblies.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Long, Assembly> e = it.next();
            if (present.contains(e.getKey()) || latest.simSeconds() <= e.getValue().simAt()) continue;
            it.remove();
            releaseBody(e.getKey());
            int placed = 0, dropped = 0;
            for (Map.Entry<class_2338, class_2680> c : e.getValue().cells().entrySet()) {
                class_2338 p = origin.method_10069(c.getKey().method_10263(), c.getKey().method_10264(), c.getKey().method_10260());
                if (!world.method_31606(p)) world.method_8497(p.method_10263() >> 4, p.method_10260() >> 4); // load it: blocks must not be lost
                if (place(c.getKey(), c.getValue())) placed++; else dropped++;
            }
            FoxPhysMod.LOGGER.warn("FoxPhys: body #{} left the physics world (beyond 128 m); its blocks returned to their original cells: {} placed, {} dropped as items", e.getKey(), placed, dropped);
        }
    }
    private void drainWorkerErrors() {
        String error = NativeBridge.workerTakeError(handle);
        if (error == null || error.isEmpty()) return;
        if (error.startsWith("F:")) {
            failed = true;
            FoxPhysMod.LOGGER.error("FoxPhys physics stopped: {}", error.substring(2));
        } else {
            // A rejected input (for example invalid terrain). The world keeps running.
            FoxPhysMod.LOGGER.warn("FoxPhys input rejected: {}", error.substring(2));
        }
    }
    /** Collision scan regions in lab coordinates: the base box plus a margin around every body. */
    private static final int SCAN_MARGIN = 2;
    private static final double GRAVITY = 9.81;
    // The physics world spans 128 m around its anchor (Rust drops bodies beyond it), so terrain
    // must be sampled to the same bound; a 64 m clamp left far bodies without colliders.
    private static final int SCAN_REACH = 128;
    private static final long SCAN_BUDGET = 60_000L;
    private void scanEnvironment(JsonObject request) {
        List<int[]> regions = new ArrayList<>();
        if (snapshot != null) {
            for (BodyState body : snapshot.bodies()) {
                if (body.aabbMin() == null || body.aabbMax() == null) continue;
                // Terrain must cover where the body can be before the next scan: its motion over that time
                // (velocity, plus free fall downwards). With a scan every tick this adds almost nothing.
                double seconds = (config.environmentScanInterval + 1) / 20.0; // server ticks are 20 per second
                float[] v = body.velocity() == null ? new float[3] : body.velocity();
                int[] r = new int[6];
                for (int a = 0; a < 3; a++) {
                    double lo = Math.max(0, -v[a]) * seconds + (a == 1 ? 0.5 * GRAVITY * seconds * seconds : 0);
                    double hi = Math.max(0, v[a]) * seconds;
                    r[a] = clamp((int) Math.floor(body.aabbMin()[a] - SCAN_MARGIN - lo), -SCAN_REACH, SCAN_REACH);
                    r[a + 3] = clamp((int) Math.ceil(body.aabbMax()[a] + SCAN_MARGIN + hi), -SCAN_REACH, SCAN_REACH);
                }
                regions.add(r);
            }
        }
        // Primitive set avoids boxing one Long for every sampled cell. Overlapping body regions
        // are charged to the scan budget only once, after deduplication.
        Set<TerrainBox> terrain = new LinkedHashSet<>();
        JsonArray water = new JsonArray();
        class_2338.class_2339 pos = new class_2338.class_2339();
        LongOpenHashSet seen = scannedCells;
        seen.clear();
        long budget = SCAN_BUDGET;
        scanSkipped = false;
        scan:
        for (int[] r : regions) {
            if (r[3] <= r[0] || r[4] <= r[1] || r[5] <= r[2]) continue;
            for (int x = r[0]; x < r[3]; x++) for (int z = r[2]; z < r[5]; z++) for (int y = r[1]; y < r[4]; y++) {
                if (!seen.add(packKey(x, y, z))) continue;
                if (budget == 0) {
                    // The budget counts unique cells actually visited, not overlapping region volume.
                    scanSkipped = true;
                    break scan;
                }
                budget--;
                pos.method_10103(origin.method_10263() + x, origin.method_10264() + y, origin.method_10260() + z);
                if (world.method_31606(pos) || !world.method_8393(pos.method_10263() >> 4, pos.method_10260() >> 4)) continue;
                class_2680 state = world.method_8320(pos);
                // Physics blocks belong to bodies (native colliders). Scanning them would collide a body with itself.
                if (state.method_27852(FoxPhysBlocks.PHYSICS_BLOCK)) continue;
                for (class_238 box : state.method_26220(world, pos).method_1090()) {
                    double sx = box.field_1320 - box.field_1323, sy = box.field_1325 - box.field_1322, sz = box.field_1324 - box.field_1321;
                    if (sx < 0.001 || sy < 0.001 || sz < 0.001) continue; // native rejects boxes below 1 mm
                    if (terrain.size() >= 16384) throw new IllegalStateException("Terrain exceeds laboratory collider budget");
                    terrain.add(new TerrainBox(
                            x + (box.field_1323 + box.field_1320) / 2,
                            y + (box.field_1322 + box.field_1325) / 2,
                            z + (box.field_1321 + box.field_1324) / 2,
                            sx, sy, sz));
                }
                var fluid = state.method_26227();
                if (fluid.method_15767(class_3486.field_15517)) {
                    float height = fluid.method_15763(world, pos);
                    if (height > 0) {
                        JsonObject cell = new JsonObject(); cell.add("cell", indices(x, y, z)); cell.addProperty("height", height);
                        // Vanilla water is sampled as a static medium in this alpha.
                        // Dynamic flow velocities come from the Rust tank solver.
                        cell.add("velocity", vector(0, 0, 0)); water.add(cell);
                    }
                }
            }
        }
        JsonArray commands = new JsonArray();
        diffTerrain(terrain, commands);
        if (commands.size() > 0) request.add("commands", commands);
        String waterJson = water.toString();
        if (!waterJson.equals(waterCache)) { request.add("water_cells", water); waterCache = waterJson; }
    }
    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }
    private static long packKey(int x, int y, int z) {
        return ((long) (x + 4096) & 0x1FFFL) << 26 | ((long) (y + 4096) & 0x1FFFL) << 13 | ((long) (z + 4096) & 0x1FFFL);
    }
    private Snapshot call(JsonObject request, boolean present) {
        if (closed) throw new IllegalStateException("Lab is closed");
        snapshot = GSON.fromJson(NativeBridge.workerCall(handle, request.toString()), Snapshot.class);
        if (snapshot == null || snapshot.abi() != NativeBridge.ABI) throw new IllegalStateException("Invalid native snapshot");
        syncSteps = snapshot.fixedSteps();
        awaitingStep = true;
        staleSnapshots = 0;
        if (present) updateVisuals();
        return snapshot;
    }
    public class_3218 world() { return world; }
    /** Dynamic state (bodies, springs, joints, wind) as the Rust SavedState JSON. Terrain and water are not saved. */
    public JsonObject exportState() {
        if (closed || failed) throw new IllegalStateException("Физика не запущена");
        JsonObject request = new JsonObject(); JsonArray list = new JsonArray();
        list.add(op("export_state")); request.add("commands", list);
        String json = NativeBridge.workerCall(handle, request.toString());
        JsonObject root = com.google.gson.JsonParser.parseString(json).getAsJsonObject();
        JsonObject result = root.getAsJsonArray("results").get(0).getAsJsonObject();
        if (!result.get("ok").getAsBoolean()) throw new IllegalStateException(result.get("message").getAsString());
        snapshot = GSON.fromJson(json, Snapshot.class);
        return result.getAsJsonObject("state");
    }
    /** Replaces bodies, springs and joints with a saved state. Rolled back on the Rust side if invalid. */
    public String importState(JsonObject state) {
        if (closed || failed) throw new IllegalStateException("Физика не запущена");
        JsonObject request = new JsonObject(); JsonArray list = new JsonArray();
        JsonObject command = op("import_state"); command.add("state", state); list.add(command);
        request.add("commands", list);
        Snapshot result = call(request, true);
        for (Result r : result.results()) if (!r.ok()) throw new IllegalArgumentException(r.message());
        scanPending = true; // the imported bodies need terrain under them before they fall: scan on the next tick
        return result.results().get(0).message();
    }
    public void commands(JsonObject... commands) {
        if (failed) throw new IllegalStateException("Physics world failed; restart the server");
        JsonObject request=new JsonObject(); JsonArray list=new JsonArray();
        for (JsonObject c:commands) list.add(c); request.add("commands",list);
        Snapshot result=call(request,true);
        for (Result r:result.results()) if (!r.ok()) throw new IllegalArgumentException(r.message());
    }
    public long spawn(String kind, float[] position) {
        long id=nextId++;
        JsonObject body=new JsonObject(); body.addProperty("id",id); body.add("position",GSON.toJsonTree(position));
        JsonArray parts=new JsonArray();
        switch (kind) {
            case "wood" -> parts.add(part(0,0,0,1,1,1,550,"minecraft:oak_planks"));
            case "stone" -> parts.add(part(0,0,0,1,1,1,2600,"minecraft:stone"));
            case "boat" -> {
                for (int x=-1;x<=1;x++) for (int z=-2;z<=2;z++) parts.add(part(x,0,z,1,1,1,550,"minecraft:oak_planks"));
                for (int x=-1;x<=1;x++) for (int z=-2;z<=2;z++) {
                    if (Math.abs(x)==1 || Math.abs(z)==2) parts.add(part(x,1,z,1,1,1,550,"minecraft:oak_planks"));
                }
                // Material-only buoyancy: enclosed air/flooding is NOT implemented yet.
            }
            case "wing" -> {
                parts.add(part(0,0,0,4,0.12,1.2,450,"minecraft:spruce_planks"));
                body.add("rotation",vector(-Math.sin(0.06),0,0,Math.cos(0.06)));
                JsonObject wing=new JsonObject();
                wing.add("center",vector(0,0,0)); wing.add("span",vector(1,0,0));
                wing.add("chord",vector(0,0,1)); wing.add("normal",vector(0,1,0));
                wing.addProperty("area",4.8); wing.addProperty("aspect_ratio",16.0/4.8); body.add("wing",wing);
            }
            default -> throw new IllegalArgumentException("Types: wood, stone, boat, wing");
        }
        body.add("parts",parts);
        JsonObject command=op("add_body"); command.add("body",body); commands(command);
        FoxPhysEvents.BODY_SPAWNED.invoker().accept(new BodySpawnedEvent(world, id, kind));
        return id;
    }
    public long springDemo() {
        long id=nextId++;
        JsonObject body=new JsonObject(); body.addProperty("id",id); body.add("position",vector(3,12,3));
        JsonArray parts=new JsonArray(); parts.add(part(0,0,0,0.5,0.5,0.5,7800,"minecraft:iron_block")); body.add("parts",parts);
        JsonObject add=op("add_body"); add.add("body",body);
        JsonObject spring=new JsonObject(); spring.addProperty("id",id); spring.add("a",com.google.gson.JsonNull.INSTANCE);
        spring.addProperty("b",id); spring.add("anchor_a",vector(3,16,3)); spring.add("anchor_b",vector(0,0,0));
        spring.addProperty("rest_length",2); spring.addProperty("stiffness",6000); spring.addProperty("damping",1400);
        JsonObject connect=op("add_spring"); connect.add("spring",spring); commands(add,connect);
        markers.add(boxDisplay(class_2246.field_10205.method_9564(),new float[]{3,16,3},new float[]{0.3f,0.3f,0.3f}));
        return id;
    }
    public void water(boolean damBreak) {
        TankSpec spec=new TankSpec(new float[]{2,4,2},12,12,1,damBreak?3:2,damBreak?0.35f:2,0.001f,0.04f);
        JsonObject command=op("set_tank"); command.add("tank",GSON.toJsonTree(spec)); commands(command);
    }
    private static JsonObject part(double x,double y,double z,double sx,double sy,double sz,double density,String block) {
        JsonObject p=new JsonObject(); p.add("offset",vector(x,y,z));p.add("size",vector(sx,sy,sz));p.addProperty("density",density);
        p.addProperty("block",block);return p;
    }
    private void updateVisuals() {
        Set<Long> active=new HashSet<>();
        for (BodyState body:snapshot.bodies()) {
            active.add(body.id());
            Assembly record=assemblies.get(body.id());
            if (record!=null && record.blocks()) {
                // Drawn by its PhysicsBlocks (and cell displays for unplaced cells): no part displays.
                List<class_8113.class_8115> old=bodyVisuals.remove(body.id());
                if (old!=null) removeAll(old);
                continue;
            }
            List<class_8113.class_8115> displays=bodyVisuals.get(body.id());
            if (displays==null || displays.size()!=body.parts().size() || displays.stream().anyMatch(d->d.method_31481())) {
                if (displays!=null) removeAll(displays);
                displays=new ArrayList<>();
                for (Part p:body.parts()) {
                    class_2960 blockId=class_2960.method_12829(p.block());
                    class_2680 block=blockId==null?class_2246.field_10161.method_9564():class_7923.field_41175.method_10223(blockId).method_9564();
                    displays.add(createDisplay(block,worldPoint(body.position())));
                }
                bodyVisuals.put(body.id(),displays);
            }
            float[] rotation=body.rotation(); Quaternionf q=new Quaternionf(rotation[0],rotation[1],rotation[2],rotation[3]);
            for (int i=0;i<displays.size();i++) {
                var display=displays.get(i); var p=body.parts().get(i);
                float[] s=p.size();float[] off=p.offset();
                Vector3f translation=new Vector3f(off[0]-s[0]/2,off[1]-s[1]/2,off[2]-s[2]/2);
                q.transform(translation);
                display.method_33574(worldPoint(body.position()));
                transform(display,translation,new Quaternionf(q),new Vector3f(s[0],s[1],s[2]));
            }
        }
        for (Long id:new ArrayList<>(bodyVisuals.keySet())) {
            if (!active.contains(id)) removeAll(bodyVisuals.remove(id));
        }
        updateTank();
    }
    private void updateTank() {
        TankState tank=snapshot.tank();
        if (tank==null) { removeAll(tankVisuals); removeAll(waterVisuals);tankKey=null;return; }
        TankSpec s=tank.spec(); String key=GSON.toJson(s);
        if (!key.equals(tankKey) || tankVisuals.stream().anyMatch(d->d.method_31481()) || waterVisuals.stream().anyMatch(d->d.method_31481())) {
            removeAll(tankVisuals);removeAll(waterVisuals);tankKey=key;
            float x=s.origin()[0],y=s.origin()[1],z=s.origin()[2];float w=s.nx()*s.dx(),d=s.nz()*s.dx(),h=10;
            tankVisuals.add(boxDisplay(class_2246.field_10038.method_9564(),new float[]{x+w/2,y-0.25f,z+d/2},new float[]{w+0.4f,0.5f,d+0.4f}));
            tankVisuals.add(boxDisplay(class_2246.field_10033.method_9564(),new float[]{x-0.1f,y+h/2,z+d/2},new float[]{0.2f,h,d+0.4f}));
            tankVisuals.add(boxDisplay(class_2246.field_10033.method_9564(),new float[]{x+w+0.1f,y+h/2,z+d/2},new float[]{0.2f,h,d+0.4f}));
            tankVisuals.add(boxDisplay(class_2246.field_10033.method_9564(),new float[]{x+w/2,y+h/2,z-0.1f},new float[]{w,h,0.2f}));
            tankVisuals.add(boxDisplay(class_2246.field_10033.method_9564(),new float[]{x+w/2,y+h/2,z+d+0.1f},new float[]{w,h,0.2f}));
            int stride=config.waterDisplayStride;
            for(int iz=0;iz<s.nz();iz+=stride) for(int ix=0;ix<s.nx();ix+=stride) {
                waterVisuals.add(createDisplay(class_2246.field_10271.method_9564(),
                        worldPoint(new float[]{x+ix*s.dx(),y,z+iz*s.dx()})));
            }
        }
        int displayIndex=0; int stride=config.waterDisplayStride;
        for (int z=0;z<s.nz();z+=stride) for (int x=0;x<s.nx();x+=stride) {
            int count=0;float depth=0;
            int nz=Math.min(stride,s.nz()-z),nx=Math.min(stride,s.nx()-x);
            for(int dz=0;dz<nz;dz++) for(int dx=0;dx<nx;dx++) {depth+=tank.depths()[(z+dz)*s.nx()+x+dx];count++;}
            // Render averaging only. Physics uses the full native cell resolution.
            transform(waterVisuals.get(displayIndex++),new Vector3f(),new Quaternionf(),
                    new Vector3f(nx*s.dx(),Math.max(0.001f,depth/count),nz*s.dx()));
        }
    }
    private class_243 worldPoint(float[] local) {return new class_243(origin.method_10263()+local[0],origin.method_10264()+local[1],origin.method_10260()+local[2]);}
    private class_8113.class_8115 createDisplay(class_2680 state,class_243 position) {
        var display=new class_8113.class_8115(class_1299.field_42460,world);
        display.method_33574(position);display.method_5875(true);display.method_5684(true);display.method_5780(TAG);
        ((BlockDisplayAccessor)display).foxphys$blockState(state);
        var access=(DisplayAccessor)display;
        // Client-side interpolation over one tick hides the 20 Hz steps of the server tick.
        access.foxphys$interpolationDuration(1);
        access.foxphys$teleportDuration(1);
        access.foxphys$viewRange(1.5f);access.foxphys$displayWidth(32);access.foxphys$displayHeight(32);
        display.field_5985=true;
        manager.track(display.method_5667());
        if(!world.method_8649(display)) {manager.untrack(display.method_5667());throw new IllegalStateException("Cannot spawn display entity");}
        return display;
    }
    private class_8113.class_8115 boxDisplay(class_2680 block,float[] center,float[] size) {
        var display=createDisplay(block,worldPoint(center));
        transform(display,new Vector3f(-size[0]/2,-size[1]/2,-size[2]/2),new Quaternionf(),new Vector3f(size[0],size[1],size[2]));
        return display;
    }
    private void transform(class_8113.class_8115 display,Vector3f translation,Quaternionf rotation,Vector3f scale) {
        var access=(DisplayAccessor)display;
        access.foxphys$transformation(new class_4590(translation,rotation,scale,new Quaternionf()));
        access.foxphys$startInterpolation(0);
    }
    private void removeAll(List<class_8113.class_8115> displays) {
        for(var d:displays) {manager.untrack(d.method_5667());d.method_31472();} displays.clear();
    }
    /** Sends only the difference against the terrain the native world already holds. */
    private void diffTerrain(Set<TerrainBox> current, JsonArray commands) {
        JsonArray remove = new JsonArray();
        Iterator<Map.Entry<TerrainBox, Long>> it = terrainIds.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<TerrainBox, Long> e = it.next();
            if (!current.contains(e.getKey())) { remove.add(e.getValue()); it.remove(); }
        }
        JsonArray add = new JsonArray();
        for (TerrainBox box : current) {
            if (terrainIds.containsKey(box)) continue;
            long id = nextTerrainId++;
            terrainIds.put(box, id);
            JsonObject keyed = new JsonObject();
            keyed.addProperty("key", id);
            keyed.add("center", vector(box.centerX(), box.centerY(), box.centerZ()));
            keyed.add("size", vector(box.sizeX(), box.sizeY(), box.sizeZ()));
            add.add(keyed);
        }
        if (add.size() == 0 && remove.size() == 0) return;
        JsonObject command = op("patch_terrain");
        command.add("add", add);
        command.add("remove", remove);
        commands.add(command);
    }
    /** Physics blocks and cell displays of every assembled body, from the latest snapshot. Called once per tick while players are near. */
    private void updateBodyBlocks() {
        if (snapshot == null) return;
        for (Map.Entry<Long, Assembly> e : assemblies.entrySet()) {
            if (!e.getValue().blocks()) continue;
            BodyState body = body(e.getKey());
            if (body == null) continue; // a missing body is handled by reconcileBodies
            placeBody(e.getKey(), body, e.getValue());
        }
        for (Long id : new ArrayList<>(placedCells.keySet())) if (!isBlockBody(id)) releaseBody(id);
        for (Long id : new ArrayList<>(cellVisuals.keySet())) if (!isBlockBody(id)) releaseVisuals(id);
    }
    private boolean isBlockBody(long id) {
        Assembly a = assemblies.get(id);
        return a != null && a.blocks();
    }
    /**
     * One body: every cell gets its world centre from the body pose (position + rotation applied to
     * the cell offset from the body centroid). Cells whose centre falls in a free cell get a
     * PhysicsBlock; the rest keep a block display at the same centre.
     */
    private void placeBody(long id, BodyState body, Assembly record) {
        float[] rot = body.rotation();
        float[] pos = body.position();
        Quaternionf q = new Quaternionf(rot[0], rot[1], rot[2], rot[3]);
        Map<class_2338, class_2680> cells = record.cells();
        double cx = 0, cy = 0, cz = 0;
        for (class_2338 c : cells.keySet()) { cx += c.method_10263() + 0.5; cy += c.method_10264() + 0.5; cz += c.method_10260() + 0.5; }
        int n = Math.max(1, cells.size());
        cx /= n; cy /= n; cz /= n;

        // Phase 1: centres and target cells. A target cell is claimed by one cell only.
        Map<class_2338, class_243> centers = new LinkedHashMap<>();
        Map<class_2338, double[]> offsets = new HashMap<>();
        Map<class_2338, class_2338> target = new LinkedHashMap<>();
        Set<class_2338> claimed = new HashSet<>();
        for (class_2338 cell : cells.keySet()) {
            double[] off = {cell.method_10263() + 0.5 - cx, cell.method_10264() + 0.5 - cy, cell.method_10260() + 0.5 - cz};
            Vector3f v = new Vector3f((float) off[0], (float) off[1], (float) off[2]);
            q.transform(v);
            class_243 center = new class_243(origin.method_10263() + pos[0] + v.x, origin.method_10264() + pos[1] + v.y, origin.method_10260() + pos[2] + v.z);
            centers.put(cell, center);
            offsets.put(cell, off);
            class_2338 at = class_2338.method_49638(center);
            if (claimable(at) && claimed.add(at)) target.put(cell, at);
        }

        Map<class_2338, class_2338> placed = placedCells.computeIfAbsent(id, k -> new HashMap<>());
        // Phase 2: blocks that move to another cell (or lose their cell) leave their old place first.
        Iterator<Map.Entry<class_2338, class_2338>> it = placed.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<class_2338, class_2338> p = it.next();
            if (!p.getValue().equals(target.get(p.getKey()))) {
                removeOwned(id, p.getValue());
                it.remove();
            }
        }
        // Phase 3: place or move. A cell that cannot take its block is left to its display.
        float[] rotation = {rot[0], rot[1], rot[2], rot[3]};
        for (Map.Entry<class_2338, class_2338> t : target.entrySet()) {
            class_2338 cell = t.getKey(), at = t.getValue();
            class_243 center = centers.get(cell);
            class_2680 current = world.method_8320(at);
            if (current.method_27852(FoxPhysBlocks.PHYSICS_BLOCK)) {
                if (world.method_8321(at) instanceof PhysicsBlockEntity pb && pb.ownedBy(token, id)) {
                    pb.push(center, rotation);
                    placed.put(cell, at);
                    continue;
                }
            } else if (current.method_26215()) {
                // Air only: replacing water or plants would destroy them, and nothing would give them back.
                world.method_8652(at, FoxPhysBlocks.PHYSICS_BLOCK.method_9564(), class_2248.field_31036);
                if (world.method_8321(at) instanceof PhysicsBlockEntity pb) {
                    pb.attach(token, id, offsets.get(cell), cells.get(cell), center, rotation);
                    placed.put(cell, at);
                    continue;
                }
            }
            placed.remove(cell);
        }
        // Phase 4: displays for the cells without a block; a placed cell drops its display.
        Map<class_2338, class_8113.class_8115> visuals = cellVisuals.computeIfAbsent(id, k -> new HashMap<>());
        for (class_2338 cell : cells.keySet()) {
            if (placed.containsKey(cell)) {
                class_8113.class_8115 old = visuals.remove(cell);
                if (old != null) discard(old);
                continue;
            }
            class_243 center = centers.get(cell);
            class_8113.class_8115 d = visuals.get(cell);
            if (d == null || d.method_31481()) {
                d = createDisplay(cells.get(cell), center);
                visuals.put(cell, d);
            }
            Vector3f t = new Vector3f(0.5f, 0.5f, 0.5f);
            q.transform(t);
            t.negate(); // the display turns about the cube centre, not its corner
            d.method_33574(center);
            transform(d, t, new Quaternionf(q), new Vector3f(1, 1, 1));
        }
        visuals.keySet().removeIf(cell -> {
            if (cells.containsKey(cell) && !placed.containsKey(cell)) return false;
            discard(visuals.get(cell));
            return true;
        });
    }
    /** A cell may take a block when its chunk is loaded and it is inside the world height. */
    private boolean claimable(class_2338 at) {
        return !world.method_31606(at) && world.method_8393(at.method_10263() >> 4, at.method_10260() >> 4);
    }
    /** Removes the physics block at `at` if it belongs to this lab and body. */
    private void removeOwned(long id, class_2338 at) {
        if (!claimable(at)) return;
        if (world.method_8321(at) instanceof PhysicsBlockEntity pb && pb.ownedBy(token, id)) {
            world.method_8652(at, class_2246.field_10124.method_9564(), class_2248.field_31036);
        }
    }
    /** Removes every physics block and display of a body. The body's cells are not put back. */
    private void releaseBody(long id) {
        Map<class_2338, class_2338> placed = placedCells.remove(id);
        if (placed != null) for (class_2338 at : placed.values()) removeOwned(id, at);
        releaseVisuals(id);
    }
    private void releaseVisuals(long id) {
        Map<class_2338, class_8113.class_8115> visuals = cellVisuals.remove(id);
        if (visuals != null) for (class_8113.class_8115 d : visuals.values()) discard(d);
    }
    private void discard(class_8113.class_8115 d) {
        if (d == null) return;
        manager.untrack(d.method_5667());
        d.method_31472();
    }

    /** Body by id in the latest snapshot, or null. */
    public BodyState bodyById(long id) { return body(id); }
    private BodyState body(long id) {
        if (snapshot == null) return null;
        for (BodyState b : snapshot.bodies()) if (b.id() == id) return b;
        return null;
    }
    public int assemblyCount() { return assemblies.size(); }
    /** True when the body was made from blocks (it can be disassembled back into them). */
    public boolean isAssembly(long id) { return assemblies.containsKey(id); }
    /** Original block states of an assembly in unspecified order; empty for non-assemblies. */
    public List<class_2680> blockStates(long id) {
        Assembly assembly = assemblies.get(id);
        return assembly == null ? List.of() : List.copyOf(assembly.cells().values());
    }
    /** Lab-local cell positions and original states for provider dispatch; returns a defensive copy. */
    public Map<class_2338, class_2680> assemblyCells(long id) {
        Assembly assembly = assemblies.get(id);
        return assembly == null ? Map.of() : Map.copyOf(assembly.cells());
    }
    /** Density in kg/m^3: the material table when it has the block, otherwise a guess from the block name. */
    public static double density(class_2680 state) {
        class_2960 id = class_7923.field_41175.method_10221(state.method_26204());
        String path = id.method_12832();
        // 1. Densities registered through the API (full id, then path) always win.
        Double api = DensityTable.overridden(id.toString());
        if (api == null) api = DensityTable.overridden(path);
        if (api != null) return api;
        // 2. The per-block table (every vanilla block).
        BlockPhysics.Entry block = BlockPhysics.get(id.toString());
        if (block != null) return block.density();
        // 3. The older material table (full id, then path), then block-name heuristics.
        Double exact = DensityTable.get(id.toString());
        if (exact != null) return exact;
        Double tabled = DensityTable.get(path);
        if (tabled != null) return tabled;
        if (path.contains("glass")) return 2500;
        // Sandstone is rock, not sand: a stone-like value (estimate, until the datapack table covers it).
        if (path.endsWith("sandstone")) return 2400;
        if (path.contains("planks") || path.contains("log") || path.contains("wood") || path.contains("fence")) return 600;
        if (path.contains("leaves") || path.contains("wool") || path.contains("sponge")) return 150;
        if (path.contains("dirt") || path.contains("sand") || path.contains("gravel") || path.contains("grass") || path.contains("clay")) return 1600;
        // "ice" also matches "lattice": only real ice blocks (ice, packed_ice, blue_ice, frosted_ice).
        if (path.endsWith("ice") && !path.endsWith("lattice")) return 917;
        if (path.contains("iron") || path.contains("anvil")) return 7800;
        return 2600;
    }
    /**
     * Moves the blocks of a cube into one physics body (the /foxphys assemble command).
     */
    public String assemble(class_2338 min, int size) {
        List<class_2338> cells = new ArrayList<>();
        for (int x = min.method_10263(); x < min.method_10263() + size; x++)
            for (int y = min.method_10264(); y < min.method_10264() + size; y++)
                for (int z = min.method_10260(); z < min.method_10260() + size; z++) cells.add(new class_2338(x, y, z));
        return assembleCells(cells);
    }
    /** True when a block may become part of a body (fluids, block entities and unbreakable blocks stay). */
    public boolean convertible(class_2338 p) {
        if (world.method_31606(p) || !world.method_8393(p.method_10263() >> 4, p.method_10260() >> 4)) return false;
        class_2680 state = world.method_8320(p);
        if (state.method_26215()) return false;
        return state.method_26227().method_15769() && !state.method_31709() && state.method_26214(world, p) >= 0;
    }
    /**
     * Moves the given world cells into ONE new physics body. The blocks leave the world only after
     * the native side accepted the body, so a refusal changes nothing.
     */
    public String assembleCells(List<class_2338> worldCells) {
        AssemblyResult result = assembleBody(worldCells);
        if (result == null) return "Сборка отменена другим модом.";
        return "Сборка #" + result.id() + ": блоков " + result.blocks() + ". Блоки перенесены в тело.";
    }
    /** A new body: its id and how many blocks it took. */
    public record AssemblyResult(long id, int blocks) {}
    /**
     * Assembles the cells into a body. Returns null when an {@link AssembleRequestedEvent} listener cancelled
     * the request; nothing changes then. Throws IllegalArgumentException when no block can be taken or the
     * native side refuses the body; a refusal leaves the blocks in place.
     */
    public AssemblyResult assembleBody(List<class_2338> worldCells) {
        if (closed || failed) throw new IllegalStateException("Физика не запущена");
        AssembleRequestedEvent request = new AssembleRequestedEvent(world, worldCells);
        FoxPhysEvents.ASSEMBLE_REQUESTED.invoker().accept(request);
        if (request.isCanceled()) return null;
        Map<class_2338, class_2680> taken = takeCells(worldCells, true);
        if (taken.isEmpty()) throw new IllegalArgumentException("Нет блоков, которые можно собрать");
        long id = nextId++;
        JsonObject command = op("assemble_body");
        command.addProperty("id", id);
        command.add("cells", cellsJson(taken));
        assemblies.put(id, new Assembly(taken, snapshot == null ? 0 : snapshot.simSeconds(), true));
        try {
            commands(command); // a refusal throws here, before any block is touched
        } catch (RuntimeException e) {
            assemblies.remove(id);
            throw e;
        }
        removeFromWorld(taken);
        updateBodyBlocks(); // the cells appear as physics blocks at once, not one tick later
        scanPending = true; // until the next scan the old blocks would still be static terrain under the new body
        FoxPhysEvents.BODY_ASSEMBLED.invoker().accept(new BodyAssembledEvent(world, id, taken.size()));
        return new AssemblyResult(id, taken.size());
    }
    /** Adds the given world cells to an existing body (its orientation must be a multiple of 90 degrees). */
    public String attachCells(long id, List<class_2338> worldCells) {
        if (closed || failed) throw new IllegalStateException("Физика не запущена");
        if (body(id) == null) throw new IllegalArgumentException("Тело #" + id + " отсутствует в физике");
        Map<class_2338, class_2680> taken = takeCells(worldCells, false);
        if (taken.isEmpty()) throw new IllegalArgumentException("Нет блоков, которые можно прикрепить");
        JsonObject command = op("attach_cells");
        command.addProperty("id", id);
        command.add("cells", cellsJson(taken));
        commands(command);
        removeFromWorld(taken);
        Assembly record = assemblies.computeIfAbsent(id, k -> new Assembly(new LinkedHashMap<>(), snapshot.simSeconds(), false));
        record.cells().putAll(taken);
        updateBodyBlocks();
        scanPending = true;
        return "Тело #" + id + ": прикреплено блоков " + taken.size() + ".";
    }
    /** Lab-local cells of the given world positions that may be converted. Skips the rest. */
    private Map<class_2338, class_2680> takeCells(List<class_2338> worldCells, boolean requireNew) {
        Map<class_2338, class_2680> taken = new LinkedHashMap<>();
        Set<class_2338> seen = new HashSet<>();
        for (class_2338 p : worldCells) {
            if (!seen.add(p) || !convertible(p)) continue;
            taken.put(new class_2338(p.method_10263() - origin.method_10263(), p.method_10264() - origin.method_10264(), p.method_10260() - origin.method_10260()), world.method_8320(p));
        }
        if (taken.size() > Assembler.MAX_ASSEMBLE_CELLS) throw new IllegalArgumentException("Слишком много блоков за раз: " + taken.size() + " (лимит " + Assembler.MAX_ASSEMBLE_CELLS + ")");
        int physical = 0;
        for (Assembly a : assemblies.values()) physical += a.cells().size();
        if (physical + taken.size() > Assembler.MAX_PHYSICAL_CELLS)
            throw new IllegalArgumentException("Лимит физических блоков в мире: " + Assembler.MAX_PHYSICAL_CELLS + " (сейчас " + physical + ", добавить " + taken.size() + ")");
        return taken;
    }
    /** Cell records for the native assembler. Full cubes carry no shape; other blocks carry their collision boxes. */
    private JsonArray cellsJson(Map<class_2338, class_2680> taken) {
        JsonArray cells = new JsonArray();
        for (Map.Entry<class_2338, class_2680> e : taken.entrySet()) {
            class_2338 local = e.getKey();
            JsonObject cell = new JsonObject();
            cell.add("cell", indices(local.method_10263(), local.method_10264(), local.method_10260()));
            cell.addProperty("density", density(e.getValue()));
            cell.addProperty("block", class_7923.field_41175.method_10221(e.getValue().method_26204()).toString());
            JsonArray boxes = shapeBoxes(e.getValue(), origin.method_10069(local.method_10263(), local.method_10264(), local.method_10260()));
            if (boxes != null) cell.add("boxes", boxes);
            cells.add(cell);
        }
        return cells;
    }
    /**
     * Collision boxes of a block in cell-local units [0,1]^3, or null for a full cube.
     * An empty list means the block has no collider. More than 8 boxes fall back to one bounding box.
     */
    private JsonArray shapeBoxes(class_2680 state, class_2338 worldPos) {
        List<class_238> list = new ArrayList<>();
        for (class_238 b : state.method_26220(world, worldPos).method_1090()) {
            if (b.field_1320 - b.field_1323 < 0.001 || b.field_1325 - b.field_1322 < 0.001 || b.field_1324 - b.field_1321 < 0.001) continue;
            list.add(b);
        }
        if (list.size() == 1 && isUnitCube(list.get(0))) return null;
        if (list.size() > 8) {
            double x0 = 1, y0 = 1, z0 = 1, x1 = 0, y1 = 0, z1 = 0;
            for (class_238 b : list) {
                x0 = Math.min(x0, b.field_1323); y0 = Math.min(y0, b.field_1322); z0 = Math.min(z0, b.field_1321);
                x1 = Math.max(x1, b.field_1320); y1 = Math.max(y1, b.field_1325); z1 = Math.max(z1, b.field_1324);
            }
            list = List.of(new class_238(x0, y0, z0, x1, y1, z1));
        }
        JsonArray out = new JsonArray();
        for (class_238 b : list) {
            JsonArray a = new JsonArray();
            for (double v : new double[]{b.field_1323, b.field_1322, b.field_1321, b.field_1320, b.field_1325, b.field_1324}) {
                a.add(Math.max(0, Math.min(1, v)));
            }
            out.add(a);
        }
        return out;
    }
    private static boolean isUnitCube(class_238 b) {
        return Math.abs(b.field_1323) < 1e-6 && Math.abs(b.field_1322) < 1e-6 && Math.abs(b.field_1321) < 1e-6
                && Math.abs(b.field_1320 - 1) < 1e-6 && Math.abs(b.field_1325 - 1) < 1e-6 && Math.abs(b.field_1324 - 1) < 1e-6;
    }
    private void removeFromWorld(Map<class_2338, class_2680> taken) {
        for (class_2338 local : taken.keySet())
            world.method_8652(origin.method_10069(local.method_10263(), local.method_10264(), local.method_10260()), class_2246.field_10124.method_9564(), class_2248.field_31036);
    }
    /**
     * Returns the blocks of a body to the world. The body must be unrotated; a translated body is
     * snapped to whole blocks on the native side and its cells are matched to the recorded shape.
     */
    public String disassemble(long id) {
        if (closed || failed) throw new IllegalStateException("Физика не запущена");
        Assembly record = assemblies.get(id);
        if (record == null) throw new IllegalArgumentException("Нет сборки #" + id + " в этом мире");
        BodyState body = body(id);
        if (body == null) throw new IllegalArgumentException("Тело #" + id + " отсутствует в физике");
        if (Math.abs(body.rotation()[3]) < 0.999f) throw new IllegalArgumentException("Тело повёрнуто: разборка возможна только без поворота");
        JsonObject command = op("disassemble_body");
        command.addProperty("id", id);
        command.addProperty("snap", true);
        JsonObject request = new JsonObject();
        JsonArray list = new JsonArray(); list.add(command); request.add("commands", list);
        Snapshot result = call(request, true);
        Result r = result.results().get(0);
        if (!r.ok()) throw new IllegalArgumentException(r.message());
        assemblies.remove(id); // the body is gone natively now: its blocks must not be lost
        releaseBody(id);
        // Blocks go back shifted by the body's whole-block displacement since assembly. The body
        // origin started at the centroid of its cells, so the shift follows from its pose alone.
        class_2338 shift = poseShift(record.cells().keySet(), body.position());
        int placed = 0, dropped = 0;
        List<class_2338> returned = new ArrayList<>();
        for (Map.Entry<class_2338, class_2680> e : record.cells().entrySet()) {
            class_2338 target = e.getKey().method_10069(shift.method_10263(), shift.method_10264(), shift.method_10260());
            if (place(target, e.getValue())) {
                placed++;
                returned.add(origin.method_10069(target.method_10263(), target.method_10264(), target.method_10260()));
            } else dropped++;
        }
        FoxPhysEvents.BODY_DISASSEMBLED.invoker().accept(new BodyDisassembledEvent(world, id, returned, dropped));
        return "Тело #" + id + " разобрано: блоков возвращено " + placed + (dropped > 0 ? ", выпало предметами " + dropped : "");
    }
    /** Whole-block shift of a body since assembly, from its origin and the centroid of its cells. */
    private static class_2338 poseShift(Set<class_2338> cells, float[] position) {
        double cx = 0, cy = 0, cz = 0;
        for (class_2338 p : cells) { cx += p.method_10263() + 0.5; cy += p.method_10264() + 0.5; cz += p.method_10260() + 0.5; }
        int n = Math.max(1, cells.size());
        cx /= n; cy /= n; cz /= n;
        double dx = position[0] - cx, dy = position[1] - cy, dz = position[2] - cz;
        if (Math.abs(dx - Math.round(dx)) > 0.05 || Math.abs(dy - Math.round(dy)) > 0.05 || Math.abs(dz - Math.round(dz)) > 0.05) {
            FoxPhysMod.LOGGER.warn("FoxPhys: body moved off the block grid by ({}, {}, {}); blocks are placed at the nearest cells", dx, dy, dz);
        }
        return new class_2338((int) Math.round(dx), (int) Math.round(dy), (int) Math.round(dz));
    }
    /** Puts a block back. An occupied cell drops the block as an item instead of destroying it. */
    private boolean place(class_2338 local, class_2680 state) {
        class_2338 p = origin.method_10069(local.method_10263(), local.method_10264(), local.method_10260());
        if (!world.method_31606(p) && world.method_8393(p.method_10263() >> 4, p.method_10260() >> 4)) {
            class_2680 current = world.method_8320(p);
            if (current.method_26215() || current.method_45474()) {
                world.method_8652(p, state, class_2248.field_31036);
                return true;
            }
        }
        class_2248.method_9577(world, p, new class_1799(state.method_26204()));
        return false;
    }
    /** Puts every recorded block back and forgets the records. Bodies are not touched. */
    public int undoAssemblies() {
        int n = 0;
        for (Long id : new ArrayList<>(assemblies.keySet())) releaseBody(id);
        for (Long id : new ArrayList<>(placedCells.keySet())) releaseBody(id);
        for (Assembly a : assemblies.values()) for (Map.Entry<class_2338, class_2680> e : a.cells().entrySet()) { place(e.getKey(), e.getValue()); n++; }
        assemblies.clear();
        return n;
    }
    /** Records for the save file. Block states are saved by block id only. */
    public JsonArray assembliesJson() {
        JsonArray list = new JsonArray();
        for (Map.Entry<Long, Assembly> e : assemblies.entrySet()) {
            JsonObject item = new JsonObject();
            item.addProperty("id", e.getKey());
            JsonArray cells = new JsonArray();
            for (Map.Entry<class_2338, class_2680> c : e.getValue().cells().entrySet()) {
                JsonObject cell = new JsonObject();
                cell.add("pos", indices(c.getKey().method_10263(), c.getKey().method_10264(), c.getKey().method_10260()));
                cell.addProperty("block", class_7923.field_41175.method_10221(c.getValue().method_26204()).toString());
                cells.add(cell);
            }
            item.add("cells", cells);
            list.add(item);
        }
        return list;
    }
    /** Replaces the records after a successful state import. Blocks of the old records go back first. */
    public void loadAssemblies(JsonArray list) {
        undoAssemblies();
        if (list == null) return;
        for (JsonElement el : list) {
            JsonObject item = el.getAsJsonObject();
            long id = item.get("id").getAsLong();
            if (body(id) == null) { FoxPhysMod.LOGGER.warn("FoxPhys: saved assembly #{} has no body; its blocks are not restored", id); continue; }
            Map<class_2338, class_2680> cells = new LinkedHashMap<>();
            for (JsonElement ce : item.getAsJsonArray("cells")) {
                JsonObject cell = ce.getAsJsonObject();
                JsonArray p = cell.getAsJsonArray("pos");
                class_2960 blockId = class_2960.method_12829(cell.get("block").getAsString());
                class_2680 state = blockId == null ? class_2246.field_10161.method_9564() : class_7923.field_41175.method_10223(blockId).method_9564();
                cells.put(new class_2338(p.get(0).getAsInt(), p.get(1).getAsInt(), p.get(2).getAsInt()), state);
            }
            takeSavedCells(id, cells);
            assemblies.put(id, new Assembly(cells, snapshot.simSeconds(), true));
        }
    }

    /**
     * A restored body owns its cells again. After /foxphys clear the original blocks are back in those
     * cells; they must be taken again, or the cube would exist twice. Only a cell that still holds the
     * saved block is cleared; anything else is left alone and reported.
     */
    private void takeSavedCells(long id, Map<class_2338, class_2680> cells) {
        int taken = 0;
        for (Map.Entry<class_2338, class_2680> c : cells.entrySet()) {
            class_2338 at = origin.method_10069(c.getKey().method_10263(), c.getKey().method_10264(), c.getKey().method_10260());
            if (world.method_31606(at) || !world.method_8393(at.method_10263() >> 4, at.method_10260() >> 4)) continue;
            class_2680 now = world.method_8320(at);
            if (now.method_26215() || now.method_27852(FoxPhysBlocks.PHYSICS_BLOCK)) continue;
            if (now.method_26204() == c.getValue().method_26204()) {
                world.method_8652(at, class_2246.field_10124.method_9564(), class_2248.field_31036);
                taken++;
            } else {
                FoxPhysMod.LOGGER.warn("FoxPhys: restored assembly #{}: cell {} holds {} instead of {}; left as is",
                        id, at, now.method_26204(), c.getValue().method_26204());
            }
        }
        if (taken > 0) FoxPhysMod.LOGGER.info("FoxPhys: restored assembly #{} took {} blocks back from its cells", id, taken);
    }
    @Override public void close() { close(true); }
    /** undoAssemblies=false only after a successful save: the saved bodies keep their blocks. */
    public void close(boolean undoAssemblies) {
        if (closed) return;
        closed = true;
        if (undoAssemblies) {
            undoAssemblies();
        } else {
            // The saved bodies keep their cells in the save file; their physics blocks are left for the next load.
            for (Long id : new ArrayList<>(cellVisuals.keySet())) releaseVisuals(id);
            placedCells.clear();
            assemblies.clear();
        }
        for (Long id : new ArrayList<>(cellVisuals.keySet())) releaseVisuals(id);
        bodyVisuals.values().forEach(this::removeAll);bodyVisuals.clear();
        removeAll(tankVisuals);removeAll(waterVisuals);removeAll(markers);
        try {NativeBridge.workerDestroy(handle);} catch(RuntimeException | LinkageError e) {FoxPhysMod.LOGGER.warn("Native lab cleanup error",e);}
    }
}
