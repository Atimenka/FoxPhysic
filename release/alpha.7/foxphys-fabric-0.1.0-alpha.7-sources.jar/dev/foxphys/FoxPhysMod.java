package dev.foxphys;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1923;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import net.minecraft.class_5218;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerChunkEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import dev.foxphys.block.PhysicsBlockEntity;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class FoxPhysMod implements ModInitializer {
    public static final Logger LOGGER=LoggerFactory.getLogger("FoxPhys");
    /** One manager per JVM (one server). Set in onInitialize; mixins reach the interactions through it. */
    private static volatile LabManager MANAGER;
    public static LabManager manager() {
        LabManager m = MANAGER;
        if (m == null) throw new IllegalStateException("FoxPhys is not initialised");
        return m;
    }
    public static Interactions interactions() {return manager().interactions();}

    /** A chunk that loaded: its physics blocks are checked once the chunk is in the cache. */
    private record ChunkCheck(class_3218 world, class_1923 pos, int[] ticksLeft) {
        ChunkCheck(class_3218 world, class_1923 pos) { this(world, pos, new int[]{200}); }
    }
    private static final java.util.Queue<ChunkCheck> CHUNK_CHECKS = new java.util.concurrent.ConcurrentLinkedQueue<>();

    /** Runs on the server thread. A chunk not yet in the cache is retried for up to 200 ticks; a later load queues it again. */
    static void processChunkChecks(LabManager manager) {
        for (ChunkCheck check : new ArrayList<>(CHUNK_CHECKS)) {
            class_2818 chunk = check.world().method_14178().method_21730(check.pos().field_9181, check.pos().field_9180);
            if (chunk == null) {
                if (--check.ticksLeft()[0] <= 0) CHUNK_CHECKS.remove(check);
                continue;
            }
            CHUNK_CHECKS.remove(check);
            removeOrphanPhysicsBlocks(manager, check.world(), chunk);
        }
    }

    /** Removes physics block entities of a loaded chunk that the live lab does not own at that position. */
    static void removeOrphanPhysicsBlocks(LabManager manager, class_3218 world, class_2818 chunk) {
        List<class_2338> stale = new ArrayList<>();
        Lab lab = manager.labFor(world);
        for (class_2586 be : new ArrayList<>(chunk.method_12214().values())) {
            if (!(be instanceof PhysicsBlockEntity pb)) continue;
            if (lab == null || !lab.holdsPhysicsBlock(be.method_11016(), pb.bodyId(), pb.owner())) stale.add(be.method_11016().method_10062());
        }
        for (class_2338 p : stale) world.method_8652(p, class_2246.field_10124.method_9564(), class_2248.field_31036);
        if (!stale.isEmpty()) LOGGER.warn("FoxPhys: removed {} leftover physics blocks in chunk {}", stale.size(), chunk.method_12004());
    }

    @Override public void onInitialize() {
        Migration.migrateConfig(FabricLoader.getInstance().getConfigDir());
        FoxPhysConfig config=FoxPhysConfig.load();
        LabManager manager=new LabManager(config);
        MANAGER=manager;
        FoxPhysBlocks.register();
        manager.interactions().register();
        CommandRegistrationCallback.EVENT.register((dispatcher,registryAccess,environment)->Commands.register(dispatcher,manager));
        ServerTickEvents.END_WORLD_TICK.register(manager::tick);
        // Physics blocks belong to a body, not to the terrain: players cannot break them.
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) -> !state.method_27852(FoxPhysBlocks.PHYSICS_BLOCK));
        // A physics block whose lab no longer holds it (crash, restart, released body) is a leftover: remove it.
        // Changing blocks inside the chunk-load callback deadlocks the chunk executor, so the check is queued
        // and runs on the server thread once the chunk is in the cache.
        ServerChunkEvents.CHUNK_LOAD.register((world, chunk) -> CHUNK_CHECKS.add(new ChunkCheck(world, chunk.method_12004())));
        ServerTickEvents.END_SERVER_TICK.register(server -> processChunkChecks(manager));
        // Soft bodies: attachments follow their rigid bodies, then wind and step, then the shapes go to clients.
        // SPH water pools step after that, with the same publish-once-per-tick rule.
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            SoftAttachments.tick();
            SoftBodies.setWind(Wind.at(server.method_30002()));
            SoftBodies.tick(server);
            SoftBodies.publish(server);
            dev.foxphys.fluid.FluidWater.tick(server);
        });
        dev.foxphys.net.FoxPhysNetwork.registerTypes();
        net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.registerGlobalReceiver(
                dev.foxphys.net.FoxPhysNetwork.AlignRequest.ID,
                (payload, context) -> context.server().execute(() -> interactions().align(context.player())));
        ServerLifecycleEvents.SERVER_STARTING.register(server->Migration.migrateSaves(server.method_27050(class_5218.field_24188)));
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            manager.shutdown();
            dev.foxphys.fluid.FluidWater.clear();
        });
        ServerEntityEvents.ENTITY_LOAD.register((entity,world)->{
            // A crash may have left saved display entities. Never treat them as
            // saved native bodies: discard stale visuals as their chunks load.
            if(entity.method_5752().contains(Lab.TAG) && !manager.owns(entity.method_5667())) entity.method_31472();
        });
        ServerEntityEvents.ENTITY_UNLOAD.register((entity,world)->{
            // Ownership tracks loaded instances, not UUIDs saved in unloaded
            // chunks. A later reload must not revive a duplicate lab visual.
            if(entity.method_5752().contains(Lab.TAG)) manager.untrack(entity.method_5667());
        });
        LOGGER.info("FoxPhys alpha ready. Physics starts on first use: assemble blocks, use honey glue, or /foxphys spawn (operator permission required)");
    }
}
