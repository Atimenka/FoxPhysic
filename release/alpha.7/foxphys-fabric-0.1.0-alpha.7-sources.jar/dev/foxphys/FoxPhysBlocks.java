package dev.foxphys;

import dev.foxphys.block.PhysicsAssemblerBlock;
import dev.foxphys.block.PhysicsAssemblerBlockEntity;
import dev.foxphys.block.PhysicsBlock;
import dev.foxphys.block.PhysicsBlockEntity;
import dev.foxphys.item.GravityGunItem;
import dev.foxphys.item.HoneyGlueItem;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_7706;
import net.minecraft.class_7923;

/**
 * Registration of the physics assembler, the gravity gun and honey glue.
 *
 * Legacy ids (voxphys:*) stay registered with the same classes, so worlds and inventories saved
 * under VoxPhys still load. They are not in the creative tabs.
 */
public final class FoxPhysBlocks {
    private FoxPhysBlocks() {}

    public static final class_2960 ASSEMBLER_ID = class_2960.method_60655("foxphys", "physics_assembler");
    public static final class_2960 GUN_ID = class_2960.method_60655("foxphys", "gravity_gun");
    public static final class_2960 GLUE_ID = class_2960.method_60655("foxphys", "honey_glue");
    public static final class_2960 WATER_BUCKET_ID = class_2960.method_60655("foxphys", "physics_water_bucket");
    public static final class_2960 LEGACY_ASSEMBLER_ID = class_2960.method_60655("voxphys", "physics_assembler");
    public static final class_2960 LEGACY_GUN_ID = class_2960.method_60655("voxphys", "gravity_gun");
    public static final class_2960 PHYSICS_BLOCK_ID = class_2960.method_60655("foxphys", "physics_block");

    private static class_4970.class_2251 assemblerSettings() {
        return class_4970.class_2251.method_9637().method_9632(3.5f).method_29292();
    }

    public static final class_2248 ASSEMBLER = class_2378.method_10230(class_7923.field_41175, ASSEMBLER_ID,
            new PhysicsAssemblerBlock(assemblerSettings()));
    public static final class_1792 ASSEMBLER_ITEM = class_2378.method_10230(class_7923.field_41178, ASSEMBLER_ID,
            new class_1747(ASSEMBLER, new class_1792.class_1793()));
    public static final class_1792 GUN = class_2378.method_10230(class_7923.field_41178, GUN_ID,
            new GravityGunItem(new class_1792.class_1793().method_7889(1)));
    public static final class_1792 GLUE = class_2378.method_10230(class_7923.field_41178, GLUE_ID,
            new HoneyGlueItem(new class_1792.class_1793().method_7889(16)));

    /** Legacy VoxPhys ids: same behaviour, hidden from creative. */
    public static final class_2248 LEGACY_ASSEMBLER = class_2378.method_10230(class_7923.field_41175, LEGACY_ASSEMBLER_ID,
            new PhysicsAssemblerBlock(assemblerSettings()));
    public static final class_1792 LEGACY_ASSEMBLER_ITEM = class_2378.method_10230(class_7923.field_41178, LEGACY_ASSEMBLER_ID,
            new class_1747(LEGACY_ASSEMBLER, new class_1792.class_1793()));
    public static final class_1792 LEGACY_GUN = class_2378.method_10230(class_7923.field_41178, LEGACY_GUN_ID,
            new GravityGunItem(new class_1792.class_1793().method_7889(1)));

    public static final class_2591<PhysicsAssemblerBlockEntity> ASSEMBLER_ENTITY = class_2378.method_10230(
            class_7923.field_41181, ASSEMBLER_ID,
            class_2591.class_2592.method_20528(PhysicsAssemblerBlockEntity::new, ASSEMBLER, LEGACY_ASSEMBLER).method_11034(null));

    /** Debug item (creative only): a bucket of SPH water. */
    public static final class_1792 WATER_BUCKET = class_2378.method_10230(class_7923.field_41178, WATER_BUCKET_ID,
            new dev.foxphys.item.PhysicsWaterBucketItem(new class_1792.class_1793().method_7889(1)));

    /**
     * Block of an assembled body while it is in the world. Not in the creative tabs and not obtainable:
     * it exists only as a body cell. Unbreakable by hardness; players are refused in FoxPhysMod.
     */
    public static final class_2248 PHYSICS_BLOCK = class_2378.method_10230(class_7923.field_41175, PHYSICS_BLOCK_ID,
            new PhysicsBlock(class_4970.class_2251.method_9637().method_22488().method_9629(-1.0f, 3600000.0f).method_42327()));

    public static final class_2591<PhysicsBlockEntity> PHYSICS_BLOCK_ENTITY = class_2378.method_10230(
            class_7923.field_41181, PHYSICS_BLOCK_ID,
            class_2591.class_2592.method_20528(PhysicsBlockEntity::new, PHYSICS_BLOCK).method_11034(null));

    /** Forces class initialisation (and so registration) during mod start-up. */
    public static void register() {
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40197).register(entries -> entries.method_45421(ASSEMBLER_ITEM));
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060).register(entries -> {
            entries.method_45421(GUN);
            entries.method_45421(GLUE);
            entries.method_45421(WATER_BUCKET);
        });
    }
}
