package dev.foxphys.net;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/**
 * Network payloads of FoxPhys (Fabric). Both are server to client.
 *
 * SoftMeshes: the current shape of every soft body, sent once per server tick.
 * FluidFrame: the particle positions of every SPH water pool near the player, sent once per server tick.
 */
public final class FoxPhysNetwork {
    private FoxPhysNetwork() {}

    private static class_2960 id(String path) {
        return class_2960.method_60655("foxphys", path);
    }

    /** One soft body: particle positions (x, y, z per particle, world space) and surface triangles. */
    /** AlignRequest (client to server): the R key was pressed in the gravity gun. */
    public record AlignRequest() implements class_8710 {
        public static final class_8710.class_9154<AlignRequest> ID = new class_8710.class_9154<>(id("align_request"));
        public static final class_9139<class_9129, AlignRequest> CODEC = class_9139.method_56431(new AlignRequest());

        @Override
        public class_8710.class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    public record SoftMesh(int id, String preset, float[] positions, int[] triangles) {}

    public record SoftMeshes(List<SoftMesh> meshes) implements class_8710 {
        public static final class_8710.class_9154<SoftMeshes> ID = new class_8710.class_9154<>(id("soft_meshes"));
        public static final class_9139<class_9129, SoftMeshes> CODEC = class_9139.method_56438(SoftMeshes::write, SoftMeshes::read);

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }

        private static void write(SoftMeshes value, class_9129 buf) {
            buf.method_10804(value.meshes().size());
            for (SoftMesh m : value.meshes()) {
                buf.method_10804(m.id());
                buf.method_10788(m.preset(), 32);
                buf.method_10804(m.positions().length);
                for (float f : m.positions()) buf.method_52941(f);
                buf.method_10804(m.triangles().length);
                for (int t : m.triangles()) buf.method_10804(t);
            }
        }

        private static SoftMeshes read(class_9129 buf) {
            int count = buf.method_10816();
            List<SoftMesh> meshes = new ArrayList<>(count);
            for (int i = 0; i < count; i++) {
                int id = buf.method_10816();
                String preset = buf.method_10800(32);
                float[] positions = new float[buf.method_10816()];
                for (int k = 0; k < positions.length; k++) positions[k] = buf.readFloat();
                int[] triangles = new int[buf.method_10816()];
                for (int k = 0; k < triangles.length; k++) triangles[k] = buf.method_10816();
                meshes.add(new SoftMesh(id, preset, positions, triangles));
            }
            return new SoftMeshes(meshes);
        }
    }

    /** One SPH water pool: anchor corner (world), particle spacing, particle positions relative to the anchor. */
    public record FluidPoolFrame(int id, double x, double y, double z, float dx, float[] xyz) {}

    public record FluidFrame(List<FluidPoolFrame> pools) implements class_8710 {
        public static final class_8710.class_9154<FluidFrame> ID = new class_8710.class_9154<>(id("fluid_frame"));
        public static final class_9139<class_9129, FluidFrame> CODEC = class_9139.method_56438(FluidFrame::write, FluidFrame::read);

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }

        private static void write(FluidFrame value, class_9129 buf) {
            buf.method_10804(value.pools().size());
            for (FluidPoolFrame f : value.pools()) {
                buf.method_10804(f.id());
                buf.method_52940(f.x());
                buf.method_52940(f.y());
                buf.method_52940(f.z());
                buf.method_52941(f.dx());
                buf.method_10804(f.xyz().length);
                for (float v : f.xyz()) buf.method_52941(v);
            }
        }

        private static FluidFrame read(class_9129 buf) {
            int count = buf.method_10816();
            List<FluidPoolFrame> pools = new ArrayList<>(count);
            for (int i = 0; i < count; i++) {
                int id = buf.method_10816();
                double x = buf.readDouble(), y = buf.readDouble(), z = buf.readDouble();
                float dx = buf.readFloat();
                float[] xyz = new float[buf.method_10816()];
                for (int k = 0; k < xyz.length; k++) xyz[k] = buf.readFloat();
                pools.add(new FluidPoolFrame(id, x, y, z, dx, xyz));
            }
            return new FluidFrame(pools);
        }
    }

    /** Registers the payload types. Called from the common initializer (server and client). */
    public static void registerTypes() {
        PayloadTypeRegistry.playS2C().register(SoftMeshes.ID, SoftMeshes.CODEC);
        PayloadTypeRegistry.playS2C().register(FluidFrame.ID, FluidFrame.CODEC);
        PayloadTypeRegistry.playC2S().register(AlignRequest.ID, AlignRequest.CODEC);
    }
}
