package dev.foxphys.mixin;

import net.minecraft.class_4590;
import net.minecraft.class_8113;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/** Presentation access only. No physics runs in these mixins. */
@Mixin(class_8113.class)
public interface DisplayAccessor {
    @Invoker("setTransformation") void foxphys$transformation(class_4590 value);
    @Invoker("setInterpolationDuration") void foxphys$interpolationDuration(int value);
    @Invoker("setStartInterpolation") void foxphys$startInterpolation(int value);
    @Invoker("setTeleportDuration") void foxphys$teleportDuration(int value);
    @Invoker("setViewRange") void foxphys$viewRange(float value);
    @Invoker("setDisplayWidth") void foxphys$displayWidth(float value);
    @Invoker("setDisplayHeight") void foxphys$displayHeight(float value);
}
