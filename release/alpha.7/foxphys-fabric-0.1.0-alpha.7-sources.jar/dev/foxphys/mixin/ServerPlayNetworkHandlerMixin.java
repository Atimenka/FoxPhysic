package dev.foxphys.mixin;

import dev.foxphys.FoxPhysMod;
import net.minecraft.class_1268;
import net.minecraft.class_2879;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Left-click detection. Air swings send no vanilla event, so the arm-swing packet is the only
 * signal for hitting a body without a block or entity in front. The work is deferred to the
 * server thread: the packet handler may run on the network thread.
 */
@Mixin(class_3244.class)
public abstract class ServerPlayNetworkHandlerMixin {
    @Shadow
    public class_3222 player;

    @Inject(method = "onHandSwing", at = @At("HEAD"))
    private void foxphys$onHandSwing(class_2879 packet, CallbackInfo ci) {
        if (packet.method_12512() != class_1268.field_5808 || this.player == null) return;
        class_3222 swinging = this.player;
        // Vanilla hands the packet to the server thread and calls this method again there. Only the
        // server-thread call acts, otherwise one swing would launch a held body and also hit it.
        if (!swinging.method_5682().method_18854()) return;
        swinging.method_5682().execute(() -> FoxPhysMod.interactions().onSwing(swinging));
    }
}
