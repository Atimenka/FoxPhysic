package dev.foxphys.mixin;

import dev.foxphys.FoxPhysMod;
import dev.foxphys.Lab;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1927.class)
public abstract class ExplosionMixin {
    @Shadow @Final private class_1937 world;

    @Inject(method = "collectBlocksAndDamageEntities", at = @At("TAIL"))
    private void foxphys$pushRigidBodies(CallbackInfo ci) {
        if (!(world instanceof class_3218 serverWorld)) return;
        class_1927 explosion = (class_1927) (Object) this;
        try {
            Lab lab = FoxPhysMod.manager().labFor(serverWorld);
            if (lab != null) lab.applyExplosion(explosion.method_55109(), explosion.method_55107());
        } catch (RuntimeException | LinkageError e) {
            FoxPhysMod.LOGGER.warn("FoxPhys could not apply explosion impulses", e);
        }
    }
}
