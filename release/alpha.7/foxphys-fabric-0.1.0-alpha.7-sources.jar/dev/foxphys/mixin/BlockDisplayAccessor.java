package dev.foxphys.mixin;

import net.minecraft.class_2680;
import net.minecraft.class_8113;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_8113.class_8115.class)
public interface BlockDisplayAccessor {
    @Invoker("setBlockState") void foxphys$blockState(class_2680 value);
}
