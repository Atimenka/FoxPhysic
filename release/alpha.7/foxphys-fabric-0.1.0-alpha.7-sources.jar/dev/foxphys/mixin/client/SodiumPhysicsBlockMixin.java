package dev.foxphys.mixin.client;

import com.llamalad7.mixinextras.sugar.ref.LocalBooleanRef;
import dev.foxphys.block.PhysicsBlockEntity;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import java.util.SortedSet;
import net.minecraft.class_2338;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4599;
import net.minecraft.class_746;
import net.minecraft.class_824;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Sodium draws global block entities only from sections it considers visible. A physics block is
 * drawn at its body's pose, so its cell's section can be hidden (occluded) while the cube is in the
 * open. After Sodium's pass, every live physics block whose cell Sodium did not draw is drawn here,
 * with the same transform Sodium uses for block entities.
 *
 * Sodium is not a compile dependency: the target is a string and {@link FoxPhysMixinPlugin} applies
 * this only when Sodium is loaded. require=0: a Sodium whose method differs is skipped.
 */
@Pseudo
@Mixin(targets = "net.caffeinemc.mods.sodium.client.render.SodiumWorldRenderer", remap = false)
public abstract class SodiumPhysicsBlockMixin {
    @Shadow
    public abstract boolean isBoxVisible(double x1, double y1, double z1, double x2, double y2, double z2);

    @Inject(method = "renderGlobalBlockEntities", at = @At("TAIL"), require = 0)
    private void foxphys$drawHiddenPhysicsBlocks(class_4587 matrices, class_4599 buffers,
                                                 Long2ObjectMap<SortedSet<?>> breaking, float tickDelta,
                                                 class_4597.class_4598 bufferSource,
                                                 double camX, double camY, double camZ,
                                                 class_824 dispatcher,
                                                 class_746 player, LocalBooleanRef glow,
                                                 CallbackInfo ci) {
        for (PhysicsBlockEntity be : PhysicsBlockEntity.clientLive()) {
            if (be.method_11015() || be.method_10997() == null) continue;
            class_2338 cell = be.method_11016();
            // Stale entries (unloaded chunk, replaced block) are not drawn.
            if (be.method_10997().method_8321(cell) != be) continue;
            // Sodium drew this block entity if its cell's section was visible.
            if (isBoxVisible(cell.method_10263(), cell.method_10264(), cell.method_10260(), cell.method_10263() + 1, cell.method_10264() + 1, cell.method_10260() + 1)) continue;
            matrices.method_22903();
            matrices.method_22904(cell.method_10263() - camX, cell.method_10264() - camY, cell.method_10260() - camZ);
            dispatcher.method_3555(be, tickDelta, matrices, bufferSource);
            matrices.method_22909();
        }
    }
}
