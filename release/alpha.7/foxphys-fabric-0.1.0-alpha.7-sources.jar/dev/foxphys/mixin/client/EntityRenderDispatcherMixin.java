package dev.foxphys.mixin.client;

import dev.foxphys.Lab;
import net.minecraft.class_1297;
import net.minecraft.class_4604;
import net.minecraft.class_8113;
import net.minecraft.class_898;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Presentation only. Lab bodies are drawn as block displays. The vanilla dispatcher also tests a display against
 * the view frustum, using the display's culling box, and that box is refreshed only when the display's transform
 * is refreshed. For a body that moves fast this test can hide a visible body. Lab displays therefore skip the
 * frustum test and keep the distance test, so far-away displays still cost nothing. Other entities keep the
 * vanilla decision. require=0: if the method differs in another build, vanilla culling applies.
 */
@Mixin(class_898.class)
public abstract class EntityRenderDispatcherMixin {
    @Inject(method = "shouldRender(Lnet/minecraft/entity/Entity;Lnet/minecraft/client/render/Frustum;DDD)Z",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void foxphys$keepLabBodiesInFrustum(class_1297 entity, class_4604 frustum, double x, double y, double z,
                                               CallbackInfoReturnable<Boolean> cir) {
        if (entity instanceof class_8113 && entity.method_5752().contains(Lab.TAG)) {
            cir.setReturnValue(entity.method_5727(x, y, z));
        }
    }
}
