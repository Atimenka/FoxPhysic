package dev.foxphys;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import dev.foxphys.Protocol.BodyState;
import dev.foxphys.Protocol.Part;
import dev.foxphys.Protocol.Snapshot;
import dev.foxphys.item.GravityGunItem;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.UUID;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import static dev.foxphys.Protocol.*;

/**
 * Player interaction with physics bodies: hand hits knock bodies back, the gravity gun holds and
 * launches them. Hit tests are exact oriented-box rays in the body frame. The physics itself stays
 * in Rust: this class only sends impulses and grab targets.
 */
public final class Interactions {
    /** Reach of a bare hand, metres. */
    static final double HAND_REACH = 4.5;
    /** Gravity gun reach for grabbing, metres. */
    static final double GUN_REACH = 16.0;
    /** A grabbed body is released beyond this distance from the holder. */
    static final double RELEASE_DISTANCE = 24.0;
    /** Velocity change of a body from one hand hit, m/s. */
    static final double HIT_DELTA_V = 1.5;
    /** Velocity change of a body launched by the gravity gun, m/s. */
    static final double LAUNCH_DELTA_V = 20.0;
    /** Ticks between two hand hits of one player. */
    static final long HIT_COOLDOWN_TICKS = 8;
    /** Hold gains: frequency (rad/s) and damping ratio; force is capped at max_accel. */
    static final double GRAB_FREQUENCY = 6.0, GRAB_DAMPING = 0.7, GRAB_MAX_ACCEL = 60.0;

    /** One grabbed body held by one player. `point` is in the body frame. */
    private record Hold(class_3222 player, long bodyId, float[] point, double distance) {}

    private final LabManager manager;
    private final Map<UUID, Hold> holds = new HashMap<>();
    private final Map<UUID, Long> lastHit = new HashMap<>();

    public Interactions(LabManager manager) {
        this.manager = manager;
    }

    /** Registers the right-click handler (gravity gun grab and release). */
    public void register() {
        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (world.field_9236 || !(player instanceof class_3222 sp)) return class_1271.method_22430(player.method_5998(hand));
            if (hand != class_1268.field_5808 || !(sp.method_6047().method_7909() instanceof GravityGunItem)) return class_1271.method_22430(sp.method_5998(hand));
            onUse(sp);
            return class_1271.method_29237(sp.method_5998(hand), false);
        });
    }

    /** Called on the server thread for a main-hand arm swing. */
    public void onSwing(class_3222 player) {
        Lab lab = manager.labFor((class_3218) player.method_37908());
        if (lab == null) return;
        Hold hold = holds.get(player.method_5667());
        if (hold != null) {
            launch(lab, player, hold);
            return;
        }
        long now = player.method_37908().method_8510();
        Long last = lastHit.get(player.method_5667());
        if (last != null && now - last < HIT_COOLDOWN_TICKS) return;
        class_243 eye = player.method_33571(), look = player.method_5828(1f);
        // A block in front of the body stops the hit: the vanilla block raycast decides first.
        double limit = HAND_REACH;
        class_239 block = player.method_5745(HAND_REACH, 0f, false);
        if (block.method_17783() != class_239.class_240.field_1333) limit = Math.min(limit, eye.method_1022(block.method_17784()));
        Pick pick = pick(lab, eye, look, limit);
        if (pick == null) return;
        lastHit.put(player.method_5667(), now);
        class_243 dir = look.method_1029();
        try {
            lab.impulse(pick.body.id(), dir.method_1021(pick.body.mass() * HIT_DELTA_V), pick.worldPoint);
            player.method_7353(class_2561.method_43470(String.format(java.util.Locale.ROOT, "Удар: тело #%d, масса %.0f кг", pick.body.id(), pick.body.mass())), true);
        } catch (RuntimeException e) {
            player.method_7353(class_2561.method_43470("FoxPhys: " + e.getMessage()), true);
        }
    }

    private void onUse(class_3222 player) {
        Lab lab = manager.labFor((class_3218) player.method_37908());
        if (lab == null) {
            player.method_7353(class_2561.method_43470("Физических тел нет: соберите блоки сборщиком или мёд-клеем"), true);
            return;
        }
        if (holds.remove(player.method_5667()) != null) {
            player.method_7353(class_2561.method_43470("Гравипушка: отпущено"), true);
            return;
        }
        class_243 eye = player.method_33571(), look = player.method_5828(1f);
        Pick pick = pick(lab, eye, look, GUN_REACH);
        if (pick == null) {
            player.method_7353(class_2561.method_43470("Гравипушка: тело не в прицеле"), true);
            return;
        }
        if (holds.size() >= 4) {
            player.method_7353(class_2561.method_43470("Гравипушка: слишком много захватов на сервере"), true);
            return;
        }
        // Body-frame grab point: the physics pulls this point, not the centre of mass.
        Vector3f local = new Vector3f(
                (float) (pick.localPoint.field_1352 - pick.body.position()[0]),
                (float) (pick.localPoint.field_1351 - pick.body.position()[1]),
                (float) (pick.localPoint.field_1350 - pick.body.position()[2]));
        new Quaternionf(pick.body.rotation()[0], pick.body.rotation()[1], pick.body.rotation()[2], pick.body.rotation()[3]).conjugate().transform(local);
        holds.put(player.method_5667(), new Hold(player, pick.body.id(), new float[]{local.x, local.y, local.z}, pick.distance));
        player.method_7353(class_2561.method_43470("Гравипушка: тело #" + pick.body.id() + " захвачено. ЛКМ — запуск, ПКМ — отпустить"), true);
    }

    private void launch(Lab lab, class_3222 player, Hold hold) {
        holds.remove(player.method_5667());
        BodyState body = lab.bodyById(hold.bodyId());
        if (body == null) return;
        class_243 dir = player.method_5828(1f).method_1029();
        try {
            lab.impulse(body.id(), dir.method_1021(body.mass() * LAUNCH_DELTA_V), lab.toWorld(new class_243(body.position()[0], body.position()[1], body.position()[2])));
            player.method_7353(class_2561.method_43470("Гравипушка: запуск тела #" + body.id()), true);
        } catch (RuntimeException e) {
            player.method_7353(class_2561.method_43470("FoxPhys: " + e.getMessage()), true);
        }
    }

    /** Grab targets for the lab's next push. Releases holds whose player, item or body is gone. */
    public JsonArray grabsFor(Lab lab) {
        JsonArray list = new JsonArray();
        Iterator<Map.Entry<UUID, Hold>> it = holds.entrySet().iterator();
        while (it.hasNext()) {
            Hold h = it.next().getValue();
            class_3222 p = h.player();
            boolean holding = !p.method_31481() && p.method_37908() == lab.world() && p.method_6047().method_7909() instanceof GravityGunItem;
            BodyState body = holding ? lab.bodyById(h.bodyId()) : null;
            class_243 eye = holding ? p.method_33571() : null;
            if (body == null || eye == null || eye.method_1022(lab.toWorld(new class_243(body.position()[0], body.position()[1], body.position()[2]))) > RELEASE_DISTANCE) {
                it.remove();
                continue;
            }
            class_243 target = lab.toLocal(eye.method_1019(p.method_5828(1f).method_1021(h.distance())));
            JsonObject grab = new JsonObject();
            grab.addProperty("id", h.bodyId());
            grab.add("point", vector(h.point()[0], h.point()[1], h.point()[2]));
            grab.add("target", vector(target.field_1352, target.field_1351, target.field_1350));
            grab.addProperty("frequency", GRAB_FREQUENCY);
            grab.addProperty("damping_ratio", GRAB_DAMPING);
            grab.addProperty("max_accel", GRAB_MAX_ACCEL);
            list.add(grab);
        }
        return list;
    }

    /** Drops every hold (lab closed, server stopping). */
    public void releaseAll() {
        holds.clear();
        lastHit.clear();
    }

    /** Body hit by a ray: world point of the hit, distance from the ray origin, and the body. */
    /**
     * R in the gravity gun: snaps the held body to the block grid (or the body in the crosshair when
     * nothing is held). The client only sends the key press; the pose is set here on the server.
     */
    public void align(class_3222 player) {
        if (!(player.method_6047().method_7909() instanceof GravityGunItem)) return;
        Lab lab = manager.labFor((class_3218) player.method_37908());
        if (lab == null) {
            player.method_7353(class_2561.method_43470("Физических тел нет: соберите блоки сборщиком или мёд-клеем"), true);
            return;
        }
        long id;
        Hold hold = holds.get(player.method_5667());
        if (hold != null) {
            id = hold.bodyId();
        } else {
            Pick pick = pick(lab, player.method_33571(), player.method_5828(1f), GUN_REACH);
            if (pick == null) {
                player.method_7353(class_2561.method_43470("Гравипушка: тело не в прицеле"), true);
                return;
            }
            id = pick.body.id();
        }
        BodyState body = lab.bodyById(id);
        if (body == null) return;
        try {
            GridAlign.Pose pose = GridAlign.align(body.position(), body.rotation(), partOffsets(body), partSizes(body));
            lab.setPose(id, pose.position(), pose.rotation());
            player.method_7353(class_2561.method_43470("Гравипушка: тело #" + id + " выровнено по сетке"), true);
        } catch (RuntimeException e) {
            player.method_7353(class_2561.method_43470("FoxPhys: " + e.getMessage()), true);
        }
    }

    private static float[][] partOffsets(BodyState body) {
        if (body.parts() == null) return new float[0][];
        float[][] out = new float[body.parts().size()][];
        for (int i = 0; i < out.length; i++) out[i] = body.parts().get(i).offset();
        return out;
    }

    private static float[][] partSizes(BodyState body) {
        if (body.parts() == null) return new float[0][];
        float[][] out = new float[body.parts().size()][];
        for (int i = 0; i < out.length; i++) out[i] = body.parts().get(i).size();
        return out;
    }

    record Pick(BodyState body, class_243 localPoint, class_243 worldPoint, double distance) {}

    /** Nearest body whose oriented box the ray hits within maxDistance (world coordinates). */
    static Pick pick(Lab lab, class_243 eyeWorld, class_243 dirWorld, double maxDistance) {
        Snapshot snap = lab.snapshot();
        if (snap == null) return null;
        class_243 o = lab.toLocal(eyeWorld), d = dirWorld.method_1029();
        Pick best = null;
        for (BodyState b : snap.bodies()) {
            double t = rayHit(b, o, d, maxDistance);
            if (Double.isNaN(t)) continue;
            if (best == null || t < best.distance()) {
                class_243 local = o.method_1019(d.method_1021(t));
                best = new Pick(b, local, lab.toWorld(local), t);
            }
        }
        return best;
    }

    /** Ray against all parts of one body. Returns the entry distance, or NaN on a miss. */
    static double rayHit(BodyState body, class_243 o, class_243 d, double maxDistance) {
        if (body.parts() == null || body.parts().isEmpty()) return Double.NaN;
        float[] r = body.rotation();
        Quaternionf inverse = new Quaternionf(r[0], r[1], r[2], r[3]).conjugate();
        Vector3f lo = inverse.transform(new Vector3f((float) (o.field_1352 - body.position()[0]), (float) (o.field_1351 - body.position()[1]), (float) (o.field_1350 - body.position()[2])));
        Vector3f ld = inverse.transform(new Vector3f((float) d.field_1352, (float) d.field_1351, (float) d.field_1350));
        double best = Double.NaN;
        for (Part p : body.parts()) {
            double t = slab(lo, ld, p, maxDistance);
            if (!Double.isNaN(t) && (Double.isNaN(best) || t < best)) best = t;
        }
        return best;
    }

    private static double slab(Vector3f lo, Vector3f ld, Part p, double maxDistance) {
        double tmin = 0, tmax = maxDistance;
        float[] min = new float[3], max = new float[3];
        for (int i = 0; i < 3; i++) {
            min[i] = (float) (p.offset()[i] - p.size()[i] / 2);
            max[i] = (float) (p.offset()[i] + p.size()[i] / 2);
        }
        float[] origin = {lo.x, lo.y, lo.z}, dir = {ld.x, ld.y, ld.z};
        for (int i = 0; i < 3; i++) {
            if (Math.abs(dir[i]) < 1e-9f) {
                if (origin[i] < min[i] || origin[i] > max[i]) return Double.NaN;
                continue;
            }
            double t1 = (min[i] - origin[i]) / dir[i], t2 = (max[i] - origin[i]) / dir[i];
            if (t1 > t2) { double tmp = t1; t1 = t2; t2 = tmp; }
            tmin = Math.max(tmin, t1);
            tmax = Math.min(tmax, t2);
            if (tmin > tmax) return Double.NaN;
        }
        return tmin;
    }
}
