package dev.foxphys.item;

import dev.foxphys.Assembler;
import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1838;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

/**
 * Honey glue. Right-click a block: the blocks connected to it (flood fill) become one physics
 * body, and one glue is used up. A refused group keeps the glue and leaves the world unchanged.
 */
public final class HoneyGlueItem extends class_1792 {
    public HoneyGlueItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        if (context.method_8045().method_8608()) return class_1269.field_5812;
        if (!(context.method_8045() instanceof class_3218 world)) return class_1269.field_5811;
        if (!(context.method_8036() instanceof class_3222 player)) return class_1269.field_5811;
        try {
            String message = Assembler.glue(world, context.method_8037());
            if (!player.method_7337()) context.method_8041().method_7934(1);
            player.method_7353(class_2561.method_43470(message), true);
            return class_1269.field_5812;
        } catch (IllegalArgumentException | IllegalStateException e) {
            player.method_7353(class_2561.method_43470("FoxPhys: " + e.getMessage()), true);
            return class_1269.field_5814;
        }
    }
}
