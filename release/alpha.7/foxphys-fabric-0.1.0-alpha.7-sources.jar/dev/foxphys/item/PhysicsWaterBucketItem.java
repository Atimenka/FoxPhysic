package dev.foxphys.item;

import dev.foxphys.FoxPhysMod;
import dev.foxphys.fluid.FluidPool;
import dev.foxphys.fluid.FluidWater;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;

/**
 * Debug item: a bucket of SPH water. Right-click on a block pours a pool of still water on the clicked face;
 * sneak + right-click pours a dam-break column instead. Creative only.
 *
 * The water is 3D particle SPH (see the fluid package). It does not yet float or push rigid bodies.
 */
public final class PhysicsWaterBucketItem extends class_1792 {
    public PhysicsWaterBucketItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        class_1937 world = context.method_8045();
        if (world.method_8608() || !(world instanceof class_3218 server)) {
            return class_1269.field_5812;
        }
        class_1657 player = context.method_8036();
        boolean dam = player != null && player.method_5715();
        class_2338 origin = context.method_8037().method_10093(context.method_8038());
        try {
            FluidPool pool = FluidWater.add(server, origin, dam);
            if (player != null) {
                player.method_7353(class_2561.method_43470(dam
                        ? "Ведро SPH-воды: прорыв плотины, " + pool.particles() + " частиц"
                        : "Ведро SPH-воды: спокойная вода, " + pool.particles() + " частиц"), true);
            }
        } catch (RuntimeException e) {
            FoxPhysMod.LOGGER.warn("Water bucket failed", e);
            if (player != null) player.method_7353(class_2561.method_43470("FoxPhys: " + e.getMessage()), true);
        }
        return class_1269.field_5812;
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 player, class_1268 hand) {
        // Air: pour above the player's head, so the bucket works without a block target.
        class_1799 stack = player.method_5998(hand);
        if (world.method_8608() || !(world instanceof class_3218 server)) {
            return class_1271.method_29237(stack, world.method_8608());
        }
        boolean dam = player.method_5715();
        try {
            FluidPool pool = FluidWater.add(server, class_2338.method_49638(player.method_19538()).method_10086(2), dam);
            player.method_7353(class_2561.method_43470("Ведро SPH-воды: " + pool.particles() + " частиц над головой"), true);
        } catch (RuntimeException e) {
            player.method_7353(class_2561.method_43470("FoxPhys: " + e.getMessage()), true);
        }
        return class_1271.method_29237(stack, false);
    }
}
