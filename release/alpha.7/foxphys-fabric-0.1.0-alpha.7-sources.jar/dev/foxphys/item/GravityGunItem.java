package dev.foxphys.item;

import net.minecraft.class_1792;

/**
 * Gravity gun. Right-click grabs the physics body in the crosshair (or releases it); left-click
 * launches the held body. The behaviour lives in dev.foxphys.Interactions.
 */
public final class GravityGunItem extends class_1792 {
    public GravityGunItem(class_1793 settings) {
        super(settings);
    }
}
