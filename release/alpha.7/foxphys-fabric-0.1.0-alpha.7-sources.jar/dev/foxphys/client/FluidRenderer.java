package dev.foxphys.client;

import dev.foxphys.net.FoxPhysNetwork.FluidFrame;
import dev.foxphys.net.FoxPhysNetwork.FluidPoolFrame;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import org.joml.Matrix4f;

/**
 * Draws SPH water pools. Each particle is a cube of the particle spacing, shaded by face and tinted by
 * height in the pool, so the water reads as a mass rather than as dots. Positions are interpolated between
 * the last two server ticks.
 *
 * This is a particle view, not a fluid surface: there is no surface reconstruction yet.
 */
public final class FluidRenderer {
    private FluidRenderer() {}

    private static final long TICK_NANOS = 50_000_000L;

    private record Frame(long receivedAt, Map<Integer, FluidPoolFrame> byId) {}

    private static volatile Frame previous;
    private static volatile Frame current;

    /** Called on the client thread with the water frame of the server tick. */
    public static void receive(FluidFrame payload) {
        Map<Integer, FluidPoolFrame> byId = new HashMap<>();
        for (FluidPoolFrame f : payload.pools()) byId.put(f.id(), f);
        previous = current;
        current = new Frame(System.nanoTime(), byId);
    }

    /** Defensive, interpolated client snapshots for the public client API. */
    public static List<dev.foxphys.api.client.FluidPoolFrame> frames(float alpha) {
        Frame now = current;
        if (now == null || now.byId().isEmpty()) return List.of();
        Frame before = previous;
        float t = Float.isFinite(alpha) ? Math.max(0f, Math.min(1f, alpha)) : 1f;
        List<dev.foxphys.api.client.FluidPoolFrame> result = new ArrayList<>(now.byId().size());
        for (FluidPoolFrame pool : now.byId().values()) {
            FluidPoolFrame old = before == null ? null : before.byId().get(pool.id());
            result.add(new dev.foxphys.api.client.FluidPoolFrame(pool.id(), pool.x(), pool.y(), pool.z(), pool.dx(),
                    interpolate(pool, old, t)));
        }
        return List.copyOf(result);
    }

    /** Stage hook: after the solid blocks, so the water sits in the world. */
    public static void render(WorldRenderContext context) {
        Frame now = current;
        if (now == null || now.byId().isEmpty()) return;
        Frame before = previous;
        float alpha = (float) Math.min(1.0, Math.max(0.0, (System.nanoTime() - now.receivedAt()) / (double) TICK_NANOS));

        class_243 camera = context.camera().method_19326();
        class_4587 poseStack = context.matrixStack();
        poseStack.method_22903();
        poseStack.method_22904(-camera.field_1352, -camera.field_1351, -camera.field_1350);
        Matrix4f matrix = poseStack.method_23760().method_23761();

        class_4597 buffers = context.consumers();
        class_1921 type = class_1921.method_49042();
        class_4588 consumer = buffers.getBuffer(type);
        for (FluidPoolFrame pool : now.byId().values()) {
            FluidPoolFrame old = before == null ? null : before.byId().get(pool.id());
            float[] pos = interpolate(pool, old, alpha);
            drawPool(consumer, matrix, pool.x(), pool.y(), pool.z(), pool.dx(), pos);
        }
        if (buffers instanceof class_4597.class_4598 immediate) immediate.method_22994(type);
        poseStack.method_22909();
    }

    private static float[] interpolate(FluidPoolFrame pool, FluidPoolFrame old, float alpha) {
        float[] pos = pool.xyz();
        if (old == null || old.xyz().length != pos.length || alpha >= 1f) return pos;
        float[] out = new float[pos.length];
        float[] prev = old.xyz();
        for (int i = 0; i < pos.length; i++) out[i] = prev[i] + (pos[i] - prev[i]) * alpha;
        return out;
    }

    private static void drawPool(class_4588 c, Matrix4f m, double ox, double oy, double oz, float dx, float[] p) {
        float top = 0f;
        for (int i = 1; i < p.length; i += 3) top = Math.max(top, p[i]);
        float h = Math.max(1e-3f, top);
        float half = dx / 2f;
        for (int i = 0; i + 2 < p.length; i += 3) {
            float x = (float) ox + p[i], y = (float) oy + p[i + 1], z = (float) oz + p[i + 2];
            // Tint: lighter near the surface.
            float depth = Math.min(1f, Math.max(0f, p[i + 1] / h));
            float r = 0.10f + 0.20f * depth, g = 0.38f + 0.22f * depth, b = 0.80f + 0.15f * depth;
            cube(c, m, x, y, z, half, r, g, b);
        }
    }

    /** Axis-aligned cube centred at (cx, cy, cz) with half-size {@code s}; each face has its own shade. */
    private static void cube(class_4588 c, Matrix4f m, float cx, float cy, float cz, float s, float r, float g, float b) {
        float x0 = cx - s, x1 = cx + s, y0 = cy - s, y1 = cy + s, z0 = cz - s, z1 = cz + s;
        // Top (lit), bottom (dark), then the four sides.
        face(c, m, x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1, r, g, b, 1.00f);
        face(c, m, x0, y0, z1, x1, y0, z1, x1, y0, z0, x0, y0, z0, r, g, b, 0.45f);
        face(c, m, x1, y0, z0, x1, y0, z1, x1, y1, z1, x1, y1, z0, r, g, b, 0.80f);
        face(c, m, x0, y0, z1, x0, y0, z0, x0, y1, z0, x0, y1, z1, r, g, b, 0.80f);
        face(c, m, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, r, g, b, 0.65f);
        face(c, m, x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0, r, g, b, 0.65f);
    }

    private static void face(class_4588 c, Matrix4f m,
                             float ax, float ay, float az, float bx, float by, float bz,
                             float cx, float cy, float cz, float dx, float dy, float dz,
                             float r, float g, float b, float shade) {
        // Both windings: the cube is visible from inside and outside, whatever the culling state.
        vertex(c, m, ax, ay, az, r * shade, g * shade, b * shade);
        vertex(c, m, bx, by, bz, r * shade, g * shade, b * shade);
        vertex(c, m, cx, cy, cz, r * shade, g * shade, b * shade);
        vertex(c, m, dx, dy, dz, r * shade, g * shade, b * shade);
        vertex(c, m, dx, dy, dz, r * shade, g * shade, b * shade);
        vertex(c, m, cx, cy, cz, r * shade, g * shade, b * shade);
        vertex(c, m, bx, by, bz, r * shade, g * shade, b * shade);
        vertex(c, m, ax, ay, az, r * shade, g * shade, b * shade);
    }

    private static void vertex(class_4588 c, Matrix4f m, float x, float y, float z, float r, float g, float b) {
        c.method_22918(m, x, y, z).method_22915(r, g, b, 1f);
    }
}
