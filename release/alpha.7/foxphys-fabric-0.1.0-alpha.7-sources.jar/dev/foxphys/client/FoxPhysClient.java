package dev.foxphys.client;

import dev.foxphys.FoxPhysBlocks;
import dev.foxphys.net.FoxPhysNetwork;
import dev.foxphys.net.FoxPhysNetwork.FluidFrame;
import dev.foxphys.net.FoxPhysNetwork.SoftMeshes;
import dev.foxphys.item.GravityGunItem;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.minecraft.class_5616;
import org.lwjgl.glfw.GLFW;

/** Client-only registrations: the physics block renderer, soft bodies, SPH water, and their packets. Server code never loads this class. */
public final class FoxPhysClient implements ClientModInitializer {
    /** R: grid-align the body held by the gravity gun (or the body in the crosshair). */
    public static final class_304 ALIGN_KEY = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.foxphys.align", class_3675.class_307.field_1668, GLFW.GLFW_KEY_R, "key.categories.foxphys"));

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Only in the world and only with the gravity gun in the main hand; other presses are ignored.
            while (ALIGN_KEY.method_1436()) {
                if (client.field_1724 != null && client.field_1755 == null
                        && client.field_1724.method_6047().method_7909() instanceof GravityGunItem) {
                    ClientPlayNetworking.send(new FoxPhysNetwork.AlignRequest());
                }
            }
        });
        class_5616.method_32144(FoxPhysBlocks.PHYSICS_BLOCK_ENTITY, PhysicsBlockRenderer::new);
        WorldRenderEvents.AFTER_TRANSLUCENT.register(context -> {
            SoftBodyRenderer.render(context);
            FluidRenderer.render(context);
        });
        ClientPlayNetworking.registerGlobalReceiver(SoftMeshes.ID,
                (payload, context) -> context.client().execute(() -> SoftBodyRenderer.receive(payload)));
        ClientPlayNetworking.registerGlobalReceiver(FluidFrame.ID,
                (payload, context) -> context.client().execute(() -> FluidRenderer.receive(payload)));
    }
}
