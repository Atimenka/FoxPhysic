package dev.foxphys.client;

import dev.foxphys.block.PhysicsBlockEntity;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_765;
import net.minecraft.class_827;
import org.joml.Quaternionf;

/**
 * Draws the original block state of a physics block at its interpolated pose.
 *
 * Opaque, translucent and animated textures follow the vanilla block entity path (render layers
 * and sprite animation come from the block renderer). Emissive blocks are drawn at full light.
 * Sodium does not replace block entity rendering, so this path is the same with or without it.
 */
public final class PhysicsBlockRenderer implements class_827<PhysicsBlockEntity> {
    public PhysicsBlockRenderer(class_5614.class_5615 context) {
    }

    @Override
    public void render(PhysicsBlockEntity entity, float tickDelta, class_4587 matrices,
                       class_4597 vertexConsumers, int light, int overlay) {
        class_2680 state = entity.originalState();
        if (state.method_26215()) return;
        class_2338 pos = entity.method_11016();
        class_243 center = entity.centerAt(tickDelta);
        Quaternionf rotation = entity.rotationAt(tickDelta);

        matrices.method_22903();
        // The entity origin is the block's own cell; the cube is rotated about its centre.
        matrices.method_22904(center.field_1352 - pos.method_10263(), center.field_1351 - pos.method_10264(), center.field_1350 - pos.method_10260());
        matrices.method_22907(rotation);
        matrices.method_22904(-0.5, -0.5, -0.5);
        int emitted = state.method_26213() > 0 ? class_765.field_32767 : light;
        class_310.method_1551().method_1541()
                .method_3353(state, matrices, vertexConsumers, emitted, overlay);
        matrices.method_22909();
    }

    /** The cube can swing outside its cell, so it is never culled by the cell's box. */
    @Override
    public boolean rendersOutsideBoundingBox(PhysicsBlockEntity entity) {
        return true;
    }
}
