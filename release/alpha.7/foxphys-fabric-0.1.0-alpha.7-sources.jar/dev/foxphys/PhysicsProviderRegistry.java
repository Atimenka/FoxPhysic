package dev.foxphys;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import dev.foxphys.api.BodyInfo;
import dev.foxphys.api.FoxPhysApi;
import dev.foxphys.api.IForceProvider;
import dev.foxphys.api.PhysicsWorld;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

/** Internal dispatcher for the public block/block-entity force-provider API. */
public final class PhysicsProviderRegistry {
    private static final int MAX_ENTITY_SCAN_CELLS = 4096;
    private static final int MAX_COMMANDS_PER_TICK = 64;
    private static final Map<class_2248, IForceProvider> BLOCKS = new ConcurrentHashMap<>();
    private static final Map<class_2591<?>, IForceProvider> BLOCK_ENTITIES = new ConcurrentHashMap<>();

    private PhysicsProviderRegistry() {}

    public static void registerBlock(class_2248 block, IForceProvider provider) { BLOCKS.put(block, provider); }
    public static boolean unregisterBlock(class_2248 block) { return BLOCKS.remove(block) != null; }
    public static void registerBlockEntity(class_2591<?> type, IForceProvider provider) { BLOCK_ENTITIES.put(type, provider); }
    public static boolean unregisterBlockEntity(class_2591<?> type) { return BLOCK_ENTITIES.remove(type) != null; }
    public static int blockProviderCount() { return BLOCKS.size(); }
    public static int blockEntityProviderCount() { return BLOCK_ENTITIES.size(); }

    /** Called once per active dimension tick, before the worker advances. */
    public static void apply(class_3218 level, Lab lab) {
        if (BLOCKS.isEmpty() && BLOCK_ENTITIES.isEmpty()) return;
        Protocol.Snapshot snapshot = lab.snapshot();
        if (snapshot == null || snapshot.bodies() == null || snapshot.bodies().isEmpty()) return;
        PhysicsWorld physics = FoxPhysApi.physics(level).orElse(null);
        if (physics == null) return;
        JsonArray commands = new JsonArray();
        for (Protocol.BodyState state : snapshot.bodies()) {
            if (commands.size() >= MAX_COMMANDS_PER_TICK) break;
            BodyInfo body = physics.body(state.id()).orElse(null);
            if (body == null) continue;
            if (!BLOCKS.isEmpty()) {
                for (Map.Entry<class_2338, class_2680> cell : lab.assemblyCells(state.id()).entrySet()) {
                    IForceProvider provider = BLOCKS.get(cell.getValue().method_26204());
                    if (provider == null) continue;
                    class_2338 source = lab.origin().method_10081(cell.getKey());
                    sample(provider, new IForceProvider.Context(level, physics, body, source,
                            cell.getValue(), null, 0.05), lab, commands);
                    if (commands.size() >= MAX_COMMANDS_PER_TICK) break;
                }
            }
            if (!BLOCK_ENTITIES.isEmpty() && commands.size() < MAX_COMMANDS_PER_TICK) {
                sampleNearbyBlockEntities(level, lab, physics, body, commands);
            }
        }
        if (!commands.isEmpty()) lab.queueCouplingImpulses(commands);
    }

    private static void sampleNearbyBlockEntities(class_3218 level, Lab lab, PhysicsWorld physics,
                                                   BodyInfo body, JsonArray commands) {
        class_238 bounds = body.bounds();
        if (bounds == null) return;
        int x0 = floor(bounds.field_1323) - 1, y0 = floor(bounds.field_1322) - 1, z0 = floor(bounds.field_1321) - 1;
        int x1 = floor(bounds.field_1320) + 1, y1 = floor(bounds.field_1325) + 1, z1 = floor(bounds.field_1324) + 1;
        long cells = (long) (x1 - x0 + 1) * (y1 - y0 + 1) * (z1 - z0 + 1);
        if (cells <= 0 || cells > MAX_ENTITY_SCAN_CELLS) return;
        for (int x = x0; x <= x1 && commands.size() < MAX_COMMANDS_PER_TICK; x++) {
            for (int y = y0; y <= y1 && commands.size() < MAX_COMMANDS_PER_TICK; y++) {
                for (int z = z0; z <= z1 && commands.size() < MAX_COMMANDS_PER_TICK; z++) {
                    if (!level.method_8393(x >> 4, z >> 4)) continue;
                    class_2338 pos = new class_2338(x, y, z);
                    if (level.method_31606(pos)) continue;
                    class_2586 entity = level.method_8321(pos);
                    if (entity == null) continue;
                    IForceProvider provider = BLOCK_ENTITIES.get(entity.method_11017());
                    if (provider == null) continue;
                    sample(provider, new IForceProvider.Context(level, physics, body, pos,
                            entity.method_11010(), entity, 0.05), lab, commands);
                }
            }
        }
    }

    private static void sample(IForceProvider provider, IForceProvider.Context context,
                               Lab lab, JsonArray commands) {
        if (commands.size() >= MAX_COMMANDS_PER_TICK) return;
        try {
            IForceProvider.Force force = provider.sample(context);
            if (force == null) return;
            if (force.force() != null) {
                if (!finite(force.force()) || (force.worldPoint() != null && !finite(force.worldPoint()))) {
                    FoxPhysMod.LOGGER.warn("FoxPhys ignored a non-finite block force provider result at {}", context.sourcePosition());
                    return;
                }
                JsonObject command = Protocol.op("apply_force");
                command.addProperty("id", context.body().id());
                command.add("force", Protocol.vector(force.force().field_1352, force.force().field_1351, force.force().field_1350));
                if (force.worldPoint() != null) {
                    class_243 point = lab.toLocal(force.worldPoint());
                    command.add("point", Protocol.vector(point.field_1352, point.field_1351, point.field_1350));
                }
                command.addProperty("duration", context.deltaSeconds());
                commands.add(command);
            }
            if (force.torque() != null && commands.size() < MAX_COMMANDS_PER_TICK) {
                if (!finite(force.torque())) {
                    FoxPhysMod.LOGGER.warn("FoxPhys ignored a non-finite block torque provider result at {}", context.sourcePosition());
                    return;
                }
                JsonObject command = Protocol.op("apply_torque");
                command.addProperty("id", context.body().id());
                command.add("torque", Protocol.vector(force.torque().field_1352, force.torque().field_1351, force.torque().field_1350));
                command.addProperty("duration", context.deltaSeconds());
                commands.add(command);
            }
        } catch (RuntimeException e) {
            FoxPhysMod.LOGGER.warn("FoxPhys block force provider failed at {}", context.sourcePosition(), e);
        }
    }

    private static int floor(double value) { return (int) Math.floor(value); }
    private static boolean finite(class_243 value) {
        return Double.isFinite(value.field_1352) && Double.isFinite(value.field_1351) && Double.isFinite(value.field_1350)
                && Math.abs(value.field_1352) <= 2_000_000 && Math.abs(value.field_1351) <= 2_000_000 && Math.abs(value.field_1350) <= 2_000_000;
    }
}
