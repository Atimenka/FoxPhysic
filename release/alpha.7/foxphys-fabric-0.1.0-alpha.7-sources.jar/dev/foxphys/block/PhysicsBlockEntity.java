package dev.foxphys.block;

import dev.foxphys.FoxPhysBlocks;
import java.util.Collection;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2512;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import org.joml.Quaternionf;

/**
 * One physics block of an assembled body, standing in the world at the cell that holds its centre.
 *
 * The pose (centre and rotation, previous and current tick) is pushed by the owning Lab every
 * tick. The client interpolates between the two poses in {@link dev.foxphys.client.PhysicsBlockRenderer}.
 * The collision shape is the original block's shape moved to the real centre of the body block.
 */
public final class PhysicsBlockEntity extends class_2586 {
    /** Lab that owns this block. A block whose owner is not a live lab is removed when its chunk loads. */
    private UUID owner;
    private long bodyId;
    /** Centre of this block relative to the body centre, in body coordinates (unrotated). */
    private double[] offset = new double[3];
    private class_2680 originalState = class_2246.field_10124.method_9564();
    private class_243 prevCenter;
    private class_243 curCenter;
    private float[] prevRotation = {0, 0, 0, 1};
    private float[] curRotation = {0, 0, 0, 1};
    private class_265 shape;

    public PhysicsBlockEntity(class_2338 pos, class_2680 state) {
        super(FoxPhysBlocks.PHYSICS_BLOCK_ENTITY, pos, state);
        prevCenter = curCenter = class_243.method_24953(pos);
    }

    /** Sets the identity and the first pose. The first pose is not interpolated. */
    public void attach(UUID owner, long bodyId, double[] offset, class_2680 original, class_243 center, float[] rotation) {
        this.owner = owner;
        this.bodyId = bodyId;
        this.offset = offset.clone();
        this.originalState = original;
        prevCenter = curCenter = center;
        prevRotation = curRotation = rotation.clone();
        shape = null;
        method_5431();
        sync();
    }

    /** Smallest move (metres) that counts as a change; smaller jitter of a resting body is not sent. */
    private static final double MOVE_EPSILON = 1e-4;
    /** Smallest rotation change (dot product of unit quaternions) that counts as a change. */
    private static final double ROTATION_EPSILON = 1e-7;

    /**
     * Moves the previous pose to the current one and sets a new current pose. Sent to clients.
     * A body at rest sends nothing per tick: the first still tick after a move sends one update
     * that makes previous and current pose equal, then the block stays silent until it moves again.
     */
    public void push(class_243 center, float[] rotation) {
        boolean moved = curCenter.method_1025(center) > MOVE_EPSILON * MOVE_EPSILON
                || rotationDot(curRotation, rotation) < 1.0 - ROTATION_EPSILON;
        if (!moved) {
            boolean settled = prevCenter.method_1025(curCenter) == 0.0
                    && rotationDot(prevRotation, curRotation) >= 1.0 - ROTATION_EPSILON;
            if (settled) return;
            prevCenter = curCenter;
            prevRotation = curRotation;
            sync();
            return;
        }
        prevCenter = curCenter;
        prevRotation = curRotation;
        curCenter = center;
        curRotation = rotation.clone();
        shape = null;
        sync();
    }

    private static double rotationDot(float[] a, float[] b) {
        return Math.abs(a[0] * b[0] + a[1] * b[1] + a[2] * b[2] + a[3] * b[3]);
    }

    public boolean ownedBy(UUID lab, long id) {
        return lab != null && lab.equals(owner) && bodyId == id;
    }

    public UUID owner() { return owner; }
    public long bodyId() { return bodyId; }
    public double[] offset() { return offset.clone(); }
    public class_2680 originalState() { return originalState; }

    /** Centre of the block at a partial tick (0 = previous pose, 1 = current pose). */
    public class_243 centerAt(float tickDelta) {
        return prevCenter.method_35590(curCenter, tickDelta);
    }

    /** Rotation at a partial tick: spherical interpolation between the two poses. */
    public Quaternionf rotationAt(float tickDelta) {
        Quaternionf from = new Quaternionf(prevRotation[0], prevRotation[1], prevRotation[2], prevRotation[3]);
        Quaternionf to = new Quaternionf(curRotation[0], curRotation[1], curRotation[2], curRotation[3]);
        return from.slerp(to, tickDelta);
    }

    /**
     * Collision and outline shape of the original block, moved so that its cube sits on the real
     * centre of the body block. Shapes that leave the cell are fine: vanilla queries the neighbours.
     */
    public class_265 collisionShape() {
        if (shape != null) return shape;
        if (originalState.method_26215()) return shape = class_259.method_1073();
        class_2338 pos = method_11016();
        class_265 base = method_10997() != null
                ? originalState.method_26220(method_10997(), pos)
                : class_259.method_1077();
        double dx = curCenter.field_1352 - (pos.method_10263() + 0.5);
        double dy = curCenter.field_1351 - (pos.method_10264() + 0.5);
        double dz = curCenter.field_1350 - (pos.method_10260() + 0.5);
        shape = base.method_1096(dx, dy, dz);
        return shape;
    }

    /** Pushes the current pose to clients that track this block. Only the block entity's data is sent. */
    private void sync() {
        if (method_10997() == null || method_10997().method_8608()) return;
        var state = method_11010();
        method_10997().method_8413(method_11016(), state, state, class_2248.field_31028);
    }

    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11007(nbt, registries);
        if (owner != null) nbt.method_25927("owner", owner);
        nbt.method_10544("body", bodyId);
        putDoubles(nbt, "offset", offset);
        nbt.method_10566("state", class_2512.method_10686(originalState));
        putDoubles(nbt, "prevCenter", new double[]{prevCenter.field_1352, prevCenter.field_1351, prevCenter.field_1350});
        putDoubles(nbt, "curCenter", new double[]{curCenter.field_1352, curCenter.field_1351, curCenter.field_1350});
        putDoubles(nbt, "prevRot", toDoubles(prevRotation));
        putDoubles(nbt, "curRot", toDoubles(curRotation));
    }

    @Override
    protected void method_11014(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11014(nbt, registries);
        owner = nbt.method_25928("owner") ? nbt.method_25926("owner") : null;
        bodyId = nbt.method_10537("body");
        double[] o = getDoubles(nbt, "offset", 3);
        if (o != null) offset = o;
        if (nbt.method_10545("state")) {
            originalState = class_2512.method_10681(registries.method_46762(class_7924.field_41254), nbt.method_10562("state"));
        }
        double[] p = getDoubles(nbt, "prevCenter", 3);
        double[] c = getDoubles(nbt, "curCenter", 3);
        prevCenter = p != null ? new class_243(p[0], p[1], p[2]) : class_243.method_24953(method_11016());
        curCenter = c != null ? new class_243(c[0], c[1], c[2]) : prevCenter;
        prevRotation = toFloats(getDoubles(nbt, "prevRot", 4), prevRotation);
        curRotation = toFloats(getDoubles(nbt, "curRot", 4), curRotation);
        shape = null;
    }

    /** Block entities loaded on the client. The Sodium mixin draws the ones Sodium's culling hides. */
    private static final Set<PhysicsBlockEntity> CLIENT_LIVE = ConcurrentHashMap.newKeySet();

    /** Live client-side physics blocks. Entries may be stale: check {@code getWorld().getBlockEntity(getPos()) == this}. */
    public static Collection<PhysicsBlockEntity> clientLive() {
        return CLIENT_LIVE;
    }

    @Override
    public void method_31662(class_1937 world) {
        super.method_31662(world);
        if (world != null && world.method_8608()) CLIENT_LIVE.add(this);
    }

    @Override
    public void method_11012() {
        super.method_11012();
        CLIENT_LIVE.remove(this);
    }

    /**
     * Chunk data and block entity updates carry this NBT to the client. The default is empty, so the
     * client never learned the original block state and drew nothing. The full NBT is sent here.
     */
    @Override
    public class_2487 method_16887(class_7225.class_7874 registries) {
        return method_38244(registries);
    }

    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    /** NBT has no double array here: values are stored as "<key>0", "<key>1", ... */
    private static void putDoubles(class_2487 nbt, String key, double[] values) {
        for (int i = 0; i < values.length; i++) nbt.method_10549(key + i, values[i]);
    }

    private static double[] getDoubles(class_2487 nbt, String key, int count) {
        if (!nbt.method_10545(key + "0")) return null;
        double[] values = new double[count];
        for (int i = 0; i < count; i++) values[i] = nbt.method_10574(key + i);
        return values;
    }

    private static double[] toDoubles(float[] f) {
        double[] d = new double[f.length];
        for (int i = 0; i < f.length; i++) d[i] = f[i];
        return d;
    }

    private static float[] toFloats(double[] d, float[] fallback) {
        if (d == null) return fallback;
        return new float[]{(float) d[0], (float) d[1], (float) d[2], (float) d[3]};
    }
}
