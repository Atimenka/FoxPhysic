package dev.foxphys.block;

import dev.foxphys.Assembler;
import dev.foxphys.FoxPhysMod;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3917;
import net.minecraft.class_9334;

/**
 * Server-side panel: a 3-row chest whose item slots are buttons. Clicks on the button slots run an
 * action; nothing can be taken or put into them. The vanilla client shows it as an ordinary chest.
 */
public final class AssemblerScreenHandler extends class_1707 {
    static final int SLOT_ASSEMBLE = 10, SLOT_ATTACH = 11, SLOT_DISASSEMBLE = 12, SLOT_INFO = 13, SLOT_RUN = 16;
    private final PhysicsAssemblerBlockEntity assembler;

    public AssemblerScreenHandler(int syncId, class_1661 playerInventory, PhysicsAssemblerBlockEntity assembler) {
        super(class_3917.field_17326, syncId, playerInventory, buttons(assembler), 3);
        this.assembler = assembler;
    }

    private static class_1277 buttons(PhysicsAssemblerBlockEntity assembler) {
        class_1277 inv = new class_1277(27);
        inv.method_5447(SLOT_ASSEMBLE, named(class_1802.field_8773, "Собрать блоки в тело"));
        inv.method_5447(SLOT_ATTACH, named(class_1802.field_8828, "Прикрепить блоки к телу рядом"));
        inv.method_5447(SLOT_DISASSEMBLE, named(class_1802.field_8403, "Разобрать тело рядом"));
        inv.method_5447(SLOT_RUN, named(class_1802.field_8131, "Запустить выбранный режим"));
        fillInfo(inv, assembler);
        return inv;
    }

    private static void fillInfo(class_1277 inv, PhysicsAssemblerBlockEntity assembler) {
        class_1799 info = named(class_1802.field_8407, "Режим: " + assembler.mode().title + " (скан 32×32×32)");
        inv.method_5447(SLOT_INFO, info);
    }

    private static class_1799 named(class_1792 item, String name) {
        class_1799 stack = new class_1799(item);
        stack.method_57379(class_9334.field_49631, class_2561.method_43470(name));
        return stack;
    }

    @Override
    public void method_7593(int slotIndex, int button, class_1713 actionType, class_1657 player) {
        if (slotIndex >= 0 && slotIndex < 27) {
            if (player instanceof class_3222 sp) act(slotIndex, sp);
            method_7623();
            return;
        }
        super.method_7593(slotIndex, button, actionType, player);
    }

    private void act(int slot, class_3222 player) {
        try {
            switch (slot) {
                case SLOT_ASSEMBLE -> assembler.setMode(Assembler.Mode.ASSEMBLE);
                case SLOT_ATTACH -> assembler.setMode(Assembler.Mode.ATTACH);
                case SLOT_DISASSEMBLE -> assembler.setMode(Assembler.Mode.DISASSEMBLE);
                case SLOT_RUN -> {
                    String message = Assembler.run((net.minecraft.class_3218) assembler.method_10997(), assembler.method_11016(), assembler.mode());
                    player.method_7353(class_2561.method_43470(message), true);
                }
                default -> { return; }
            }
            if (slot != SLOT_RUN) {
                if (method_7629() instanceof class_1277 inv) fillInfo(inv, assembler);
                player.method_7353(class_2561.method_43470("Режим: " + assembler.mode().title), true);
            }
        } catch (IllegalArgumentException | IllegalStateException e) {
            player.method_7353(class_2561.method_43470("FoxPhys: " + e.getMessage()), true);
        }
    }

    @Override
    public class_1799 method_7601(class_1657 player, int slot) {
        // Shift-click must not move items into or out of the button slots.
        return slot < 27 ? class_1799.field_8037 : super.method_7601(player, slot);
    }
}
