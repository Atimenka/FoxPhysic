package dev.foxphys.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3965;

/** Physics assembler: opens a panel with the modes and runs the chosen mode on its scanner. */
public final class PhysicsAssemblerBlock extends class_2237 {
    public static final MapCodec<PhysicsAssemblerBlock> CODEC = method_54094(PhysicsAssemblerBlock::new);

    public PhysicsAssemblerBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new PhysicsAssemblerBlockEntity(pos, state);
    }

    @Override
    protected class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        if (world.field_9236) return class_1269.field_5812;
        if (world.method_8321(pos) instanceof PhysicsAssemblerBlockEntity be) player.method_17355(be);
        return class_1269.field_21466;
    }
}
