package dev.foxphys.block;

import dev.foxphys.Assembler;
import dev.foxphys.FoxPhysBlocks;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3908;
import net.minecraft.class_7225;

/** Stores the selected mode of one assembler. */
public final class PhysicsAssemblerBlockEntity extends class_2586 implements class_3908 {
    private Assembler.Mode mode = Assembler.Mode.ASSEMBLE;

    public PhysicsAssemblerBlockEntity(class_2338 pos, class_2680 state) {
        super(FoxPhysBlocks.ASSEMBLER_ENTITY, pos, state);
    }

    public Assembler.Mode mode() {
        return mode;
    }

    public void setMode(Assembler.Mode mode) {
        this.mode = mode;
        method_5431();
    }

    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11007(nbt, registries);
        nbt.method_10582("mode", mode.id);
    }

    @Override
    protected void method_11014(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11014(nbt, registries);
        try {
            mode = Assembler.Mode.parse(nbt.method_10558("mode"));
        } catch (IllegalArgumentException e) {
            mode = Assembler.Mode.ASSEMBLE;
        }
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471("block.foxphys.physics_assembler");
    }

    @Override
    public class_1703 createMenu(int syncId, class_1661 inventory, class_1657 player) {
        return new AssemblerScreenHandler(syncId, inventory, this);
    }
}
