package dev.foxphys.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1922;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;
import net.minecraft.class_4970;

/**
 * A block of a physics body while it is in the world. It has no look of its own: the renderer
 * draws the original block state at the body pose. Its collision and outline are the original
 * block's shape at the body pose, from {@link PhysicsBlockEntity}.
 *
 * Model rendering is requested, and the model is empty (assets/foxphys/models/block/physics_block_empty.json),
 * so the chunk mesh draws nothing for it.
 */
public final class PhysicsBlock extends class_2237 {
    public PhysicsBlock(class_4970.class_2251 settings) {
        super(settings);
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return method_54094(PhysicsBlock::new);
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new PhysicsBlockEntity(pos, state);
    }

    @Override
    protected class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    protected class_265 method_9549(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return shapeAt(world, pos);
    }

    @Override
    protected class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return shapeAt(world, pos);
    }

    @Override
    protected class_265 method_26159(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return shapeAt(world, pos);
    }

    private static class_265 shapeAt(class_1922 world, class_2338 pos) {
        // No block entity (for example while the chunk loads) means no collider: never a ghost cube.
        if (world.method_8321(pos) instanceof PhysicsBlockEntity be) return be.collisionShape();
        return class_259.method_1073();
    }
}
