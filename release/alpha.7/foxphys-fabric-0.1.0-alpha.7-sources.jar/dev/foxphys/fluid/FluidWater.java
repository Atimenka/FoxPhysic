package dev.foxphys.fluid;

import dev.foxphys.net.FoxPhysNetwork.FluidFrame;
import dev.foxphys.net.FoxPhysNetwork.FluidPoolFrame;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

/**
 * Server-side registry of SPH water pools. Steps them once per server tick and sends the particle
 * positions to every player within {@link #VIEW_DISTANCE} blocks of a pool.
 */
public final class FluidWater {
    private FluidWater() {}

    public static final int MAX_POOLS = 8;
    private static final double VIEW_DISTANCE = 96.0;
    private static final double NEAR_DISTANCE = 64.0;
    private static final List<FluidPool> POOLS = new ArrayList<>();

    /** Creates a pool with its floor at {@code origin} (the block corner). Throws IllegalStateException on error. */
    public static synchronized FluidPool add(class_3218 world, class_2338 origin, boolean dam) {
        if (POOLS.size() >= MAX_POOLS) throw new IllegalStateException("too many water pools (max " + MAX_POOLS + ")");
        FluidPool pool = FluidPool.create(world, origin, dam);
        POOLS.add(pool);
        return pool;
    }

    public static synchronized int count() { return POOLS.size(); }

    /** Removes every pool (server stop or a clear command). */
    public static synchronized void clear() {
        for (FluidPool pool : POOLS) pool.close();
        POOLS.clear();
    }

    /** Steps the pools that have a player nearby, drops failed ones, and publishes the frames. */
    public static synchronized void tick(MinecraftServer server) {
        Iterator<FluidPool> it = POOLS.iterator();
        while (it.hasNext()) {
            FluidPool pool = it.next();
            try {
                dev.foxphys.Lab lab = dev.foxphys.FoxPhysMod.manager().labFor(pool.level());
                pool.advance(anyPlayerNear(server, pool, NEAR_DISTANCE), lab);
            } catch (RuntimeException e) {
                dev.foxphys.FoxPhysMod.LOGGER.error("FoxPhys water pool {} disabled after an error", pool.id(), e);
                pool.close();
                it.remove();
            }
        }
        publish(server);
    }

    private static boolean anyPlayerNear(MinecraftServer server, FluidPool pool, double radius) {
        class_243 c = centre(pool);
        for (class_3222 p : server.method_3760().method_14571()) {
            if (p.method_37908() == pool.level() && p.method_19538().method_1025(c) < radius * radius) return true;
        }
        return false;
    }

    private static class_243 centre(FluidPool pool) {
        class_2338 o = pool.origin();
        return new class_243(o.method_10263() + FluidPool.SIZE / 2, o.method_10264() + FluidPool.SIZE / 2, o.method_10260() + FluidPool.SIZE / 2);
    }

    private static void publish(MinecraftServer server) {
        for (class_3222 player : server.method_3760().method_14571()) {
            List<FluidPoolFrame> frames = new ArrayList<>();
            for (FluidPool pool : POOLS) {
                if (pool.level() != player.method_37908()) continue;
                if (player.method_19538().method_1025(centre(pool)) > VIEW_DISTANCE * VIEW_DISTANCE) continue;
                class_2338 o = pool.origin();
                frames.add(new FluidPoolFrame(pool.id(), o.method_10263(), o.method_10264(), o.method_10260(), (float) FluidPool.DX, pool.local()));
            }
            ServerPlayNetworking.send(player, new FluidFrame(frames));
        }
    }
}
